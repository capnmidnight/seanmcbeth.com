import pygame
from pygame.locals import *
import random
from math import *
#from particlesystem import *

score = 0

class Particle:
    def __init__(self, startpos, startvel, startaccel, startcol, startlife, startsize, sizestep):
        self.pos = startpos
        self.vel = startvel
        self.accel = startaccel
        self.col = startcol
        self.life = startlife
        self.size = startsize
        self.sizestep = sizestep
        

class ParticleEmitter:
    def __init__(self, maxparticles, pos, vel, accel, col, life, size, sizestep, randpos, emitterlife=60):
        self.particles = list()
        self.maxparts = maxparticles
        self.startpos = pos
        self.startvel = vel
        self.startaccel = accel
        self.startcol = col
        self.startlife = life
        self.startsize = size
        self.sizestep = sizestep
        self.randpos = randpos
        self.life = emitterlife

    def update(self):
        self.life -= 1
        if len(self.particles) < self.maxparts:
            for x in range(3):
                particlepos = (self.startpos[0] + random.randint (int(-self.randpos[0]*0.5), int(self.randpos[0]*0.5)),
                               self.startpos[1] + random.randint (int(-self.randpos[1]*0.5), int(self.randpos[1]*0.5)))
                self.particles.append (Particle (particlepos, self.startvel, self.startaccel, self.startcol, self.startlife, self.startsize, self.sizestep))
            
        for p in self.particles:
            p.vel = (p.vel[0] + p.accel[0], p.vel[1] + p.accel[1])
            p.pos = (p.pos[0] + p.vel[0], p.pos[1] + p.vel[1])
            p.size += p.sizestep
            p.life -= 1
            #p.col = (p.col[0]-5, p.col[1]-5, p.col[2]-5)
            
            if p.size <= 0:
                self.particles.remove (p)
            elif p.life <= 0:
                self.particles.remove (p)

    def burst(self, particles):
        for x in range(particles):
            particlepos = (self.startpos[0] + random.randint (int(-self.randpos[0]*0.5), int(self.randpos[0]*0.5)),
                           self.startpos[1] + random.randint (int(-self.randpos[1]*0.5), int(self.randpos[1]*0.5)))
            self.particles.append (Particle (particlepos, self.startvel, self.startaccel, self.startcol, self.startlife, self.startsize, self.sizestep))

    def render(self):
        for p in self.particles:
            if p.pos[0] <= 640 and p.pos[1] <= 480 and p.pos[0] >= 0 and p.pos[1] >= 0:
                pygame.draw.circle (screen, p.col, (int(p.pos[0]), int(p.pos[1])), int(p.size))

class Enemy:
    def __init__(self):
        self.radius = random.randint (15, 25)
        
        if random.randint (0, 1):
            if random.randint (0, 1):
                self.pos = (random.randint(0, 640), 0)
            else:
                self.pos = (random.randint(0, 640), 480)
        else:
            if random.randint (0, 1):
                self.pos = (640, random.randint(0, 480))
            else:
                self.pos = (0, random.randint(0, 480))
                
        self.vel = (0, 0)
                
    def update(self):
        stepX = playerpos[0] - self.pos[0]
        stepY = playerpos[1] - self.pos[1]
        stepmag = sqrt (stepX**2 + stepY**2)
        if stepX != 0 and stepY != 0 and stepmag != 0:
            stepX /= stepmag
            stepY /= stepmag
        else:
            stepX = 0
            stepY = 0

        self.vel = (self.vel[0] + stepX*0.2, self.vel[1] + stepY*0.2)
        
        self.pos = (self.pos[0] + self.vel[0], self.pos[1] + self.vel[1])
        
    def render(self):
        pygame.draw.circle (screen, (255, 0, 0), (int(self.pos[0]), int(self.pos[1])), self.radius, 1)

class Bullet:
    def __init__(self, pos, step):
        self.pos = pos
        self.step = (step[0]*2, step[1]*2)
        self.startstep = step
        self.emitter = ParticleEmitter (1000, pos, (-step[0], -step[1]), (0, 0), (255, 170, 20), 360, 7, -0.8, (10, 10), 90)
        global emitters
        emitters.append (self.emitter)
        #self.emitter = ParticleEmitter (70, (320, 240), (1, -2), (0, -0.33), (255, 170, 20), 360, 10, -0.2, (30, 10))
        #emitters.append (self.emitter)
        #print "BOOM!"
        
    def update(self):
        self.step = (self.step[0] + self.startstep[0], self.step[1] + self.startstep[1])
        self.pos = (self.pos[0] + self.step[0], self.pos[1] + self.step[1])
        self.emitter.startpos = self.pos
        
gamedone = False

pygame.display.set_mode ((640, 480), 0, 24)
pygame.display.set_caption ("BURN IT WITH FIRE V. 5.12041b")
pygame.font.init()
font = pygame.font.Font (None, 36)

screen = pygame.display.get_surface()

#emitter = ParticleEmitter (70, (320, 240), (1, -2), (0, -0.33), (255, 170, 20), 360, 10, -0.2, (30, 10))

playerpos = (320, 240)

emitters = list()
enemies = list()

def main():
    global emitters
    global enemies
    global score
    mousedown = False
    mousepos = (0, 0)
    bullets = list()
    shotinterval = 6
    lastfired = 0
    frame = 0
    global gamedone
    global playerpos
    playervel = (0, 0)
    moveup = False
    movedown = False
    moveleft = False
    moveright = False
    playerrad = 30
    lastenemy = 0
    enemyinterval = 10
    #emitter = ParticleEmitter (70, (320, 240), (1, -2), (0, -0.33), (255, 170, 20), 360, 10, -0.2, (30, 10))
    #emitters.append (emitter)

    showmenu = True

    titlefont = pygame.font.Font (None, 82)
    titleframe = 0

    titleemitterF = ParticleEmitter (570, (320, 240), (1, -2), (0, -0.33), (255, 170, 20), 360, 8, -0.24, (20, 10))
    titleemitterI = ParticleEmitter (570, (320, 240), (1, -2), (0, -0.33), (255, 150, 20), 360, 8, -0.24, (10, 10))
    titleemitterR = ParticleEmitter (570, (320, 240), (1, -2), (0, -0.33), (255, 130, 20), 360, 8, -0.24, (20, 10))
    titleemitterE = ParticleEmitter (570, (320, 240), (1, -2), (0, -0.33), (255, 110, 20), 360, 8, -0.24, (20, 10))
    
    while showmenu:
        for event in pygame.event.get():
             if event.type == KEYDOWN:
                 showmenu = False

        text = "BURN IT WITH FIRE"

        i = 0
        fullsize = titlefont.size (text)
        y = titleframe
        
        for x in text:
            char = titlefont.render (x, 1, (255, 200, 20, 255))
            screen.blit (char, (320-fullsize[0]*0.5+i, 240-fullsize[1]*0.5 + sin (radians (y))*15))
            if x == "F":
                titleemitterF.startpos = (320-fullsize[0]*0.5+i+15, 240-fullsize[1]*0.5 + sin (radians (y))*15+14)
            if x == "I":
                titleemitterI.startpos = (320-fullsize[0]*0.5+i+5, 240-fullsize[1]*0.5 + sin (radians (y))*15+14)
            if x == "R":
                titleemitterR.startpos = (320-fullsize[0]*0.5+i+18, 240-fullsize[1]*0.5 + sin (radians (y))*15+14)
            if x == "E":
                titleemitterE.startpos = (320-fullsize[0]*0.5+i+18, 240-fullsize[1]*0.5 + sin (radians (y))*15+14)
            i += titlefont.size(x)[0]
            y += 15

        titleframe += 10

        titleemitterF.update()
        titleemitterF.render()
        titleemitterI.update()
        titleemitterI.render()
        titleemitterR.update()
        titleemitterR.render()
        titleemitterE.update()
        titleemitterE.render()

        bytext = "by Dillon Cower"
        fullsize = titlefont.size (bytext)
        by = titlefont.render (bytext, 1, (255, 255, 255, 255))
        screen.blit (by, (320-fullsize[0]*0.5, 440-fullsize[1]*0.5))
        
        press = font.render ("Press a key, dammit!", 1, (255, 255, 255, 255))
        screen.blit (press, (10, 2))
        
        pygame.display.flip()
        pygame.display.get_surface().fill ((0, 0, 0))

        pygame.time.Clock().tick (120)

    #titlefont.quit()
    
    while gamedone == False:
        for event in pygame.event.get():
            if event.type == QUIT:
                gamedone = True
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    gamedone = True
                if event.key == K_w:
                    moveup = True
                if event.key == K_s:
                    movedown = True
                if event.key == K_a:
                    moveleft = True
                if event.key == K_d:
                    moveright = True
            if event.type == KEYUP:
                if event.key == K_w:
                    moveup = False
                if event.key == K_s:
                    movedown = False
                if event.key == K_a:
                    moveleft = False
                if event.key == K_d:
                    moveright = False
            if event.type == MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed()[0] == True and mousedown == False:
                    mousedown = True
            if event.type == MOUSEBUTTONUP:
                if pygame.mouse.get_pressed()[0] == False and mousedown == True:
                    mousedown = False

        mousepos = pygame.mouse.get_pos()

        if moveup:
            playervel = (playervel[0], playervel[1] - 1.75)
        if movedown:
            playervel = (playervel[0], playervel[1] + 1.75)
        if moveright:
            playervel = (playervel[0] + 1.75, playervel[1])
        if moveleft:
            playervel = (playervel[0] - 1.75, playervel[1])

        if playervel[1] > 0:
            playervel = (playervel[0], (playervel[1] - 0.5) * 0.95)
        if playervel[0] > 0:
            playervel = ((playervel[0] - 0.5) * 0.95, playervel[1])
        if playervel[1] < 0:
            playervel = (playervel[0], (playervel[1] + 0.5) * 0.95)
        if playervel[0] < 0:
            playervel = ((playervel[0] + 0.5) * 0.95, playervel[1])

        if playervel[0] < 0.5*0.95 and playervel[0] > -0.5*0.95:
            playervel = (0, playervel[1])
        if playervel[1] < 0.5*0.95 and playervel[1] > -0.5*0.95:
            playervel = (playervel[0], 0)

        if playerpos[0] >= 640 - playerrad:
            playerpos = (640 - playerrad - 1, playerpos[1])
            playervel = (-playervel[0]*0.75, playervel[1])
        if playerpos[0] <= playerrad:
            playerpos = (playerrad + 1, playerpos[1])
            playervel = (-playervel[0]*0.75, playervel[1])
        if playerpos[1] >= 480 - playerrad:
            playerpos = (playerpos[0], 480 - playerrad - 1)
            playervel = (playervel[0], -playervel[1]*0.75)
        if playerpos[1] <= playerrad:
            playerpos = (playerpos[0], playerrad + 1)
            playervel = (playervel[0], -playervel[1]*0.75)

        playerpos = (playerpos[0] + playervel[0], playerpos[1] + playervel[1])

        armstepX = mousepos[0] - playerpos[0]
        armstepY = mousepos[1] - playerpos[1]
        armmag = sqrt (armstepX**2 + armstepY**2)
        if armstepX != 0 and armstepY != 0 and armmag != 0:
            armstepX /= armmag
            armstepY /= armmag
        else:
            armstepX = 0
            armstepY = 0

        endcannon = (playerpos[0]+armstepX*(playerrad+40), playerpos[1]+armstepY*(playerrad+40))

        for bullet in bullets:
            bullet.update()

            if bullet.pos[0] > 640 or bullet.pos[0] < 0 or bullet.pos[1] > 480 or bullet.pos[1] < 0:
                bullet.emitter.startpos = (1600, 1600)
                bullets.remove (bullet)

        if mousedown and (frame - lastfired) > shotinterval:
            bullets.append (Bullet ((float(endcannon[0]), float(endcannon[1])), (float(armstepX), float(armstepY))))
            lastfired = frame

        for enemy in enemies:
            enemy.update()
            enemy.render()

            dist = sqrt ((enemy.pos[0] - playerpos[0])**2 + (enemy.pos[1] - playerpos[1])**2)

            if dist <= playerrad + enemy.radius:
                stepX = playerpos[0] - enemy.pos[0]
                stepY = playerpos[1] - enemy.pos[1]
                stepmag = sqrt (stepX**2 + stepY**2)
                if stepX != 0 and stepY != 0 and stepmag != 0:
                    stepX /= stepmag
                    stepY /= stepmag
                else:
                    stepX = 0
                    stepY = 0
                    
                emitter = ParticleEmitter (0, (playerpos[0] - stepX*playerrad, playerpos[1] - stepY*playerrad), (-stepX*3, -stepY*3), (0, 0), (255, 0, 0), 360, 10, -0.8, (10, 10), 40)
                emitter.burst (10)
                emitter.update()
                emitter.burst (10)
                emitter.update()
                emitter.burst (10)
                emitter.update()
                emitter.burst (10)
                emitter.update()
                emitter.burst (10)
                emitters.append (emitter)
                enemies.remove (enemy)
                playerrad -= 4
            else:
                for bullet in bullets:
                    dist = sqrt ((enemy.pos[0] - bullet.pos[0])**2 + (enemy.pos[1] - bullet.pos[1])**2)

                    if dist <= 10 + enemy.radius:
                        emitter = ParticleEmitter (0, enemy.pos, (0, 2), (0, 0), (255, 255, 255), 360, 7, -0.7, (enemy.radius+5, enemy.radius+5), 40)
                        emitter.burst (50)
                        emitters.append (emitter)
                        enemies.remove (enemy)
                        score += 10
            
        if (frame - lastenemy) > enemyinterval:
            lastenemy = frame
            enemies.append (Enemy())
        
        """#head       
        pygame.draw.circle (screen, (255, 255, 255), (playerpos[0], playerpos[1]-50), 10, 1)
        #spine
        pygame.draw.line (screen, (255, 255, 255), (playerpos[0], playerpos[1]-50+10), (playerpos[0], playerpos[1]-50+35), 1)
        #right leg
        pygame.draw.line (screen, (255, 255, 255), (playerpos[0], playerpos[1]-50+35), (playerpos[0]+10, playerpos[1]), 1)
        #left leg
        pygame.draw.line (screen, (255, 255, 255), (playerpos[0], playerpos[1]-50+35), (playerpos[0]-10, playerpos[1]), 1)
        #right arm
        pygame.draw.line (screen, (255, 255, 255), (playerpos[0], playerpos[1]-50+35), (playerpos[0]+10, playerpos[1]), 1)
        #left arm
        pygame.draw.line (screen, (255, 255, 255), (playerpos[0], playerpos[1]-50+35), (playerpos[0]-10, playerpos[1]), 1)"""

        global emitters

        for emitter in emitters:
            if emitter.life <= 0:
                emitters.remove (emitter)
            else:
                emitter.update()
                emitter.render()

        if playerrad >= 10:
            #draw ze player
            pygame.draw.circle (screen, (0, 0, 0), (int(playerpos[0]), int(playerpos[1])), playerrad)
            pygame.draw.circle (screen, (255, 255, 255), (int(playerpos[0]), int(playerpos[1])), playerrad, 1)
            pygame.draw.line (screen, (255, 255, 255), (playerpos[0]+armstepX*playerrad, playerpos[1]+armstepY*playerrad), endcannon, 3)
        else:
            gameover = True
            pygame.display.get_surface().fill ((128, 128, 128))
            while gameover:
                enemies = list()
                emitters = list()
                mousedown = False
                mousepos = (0, 0)
                bullets = list()
                shotinterval = 6
                lastfired = 0
                frame = 0
                playervel = (0, 0)
                moveup = False
                movedown = False
                moveleft = False
                moveright = False
                playerrad = 30
                lastenemy = 0
                enemyinterval = 10
                
                for event in pygame.event.get():
                 if event.type == KEYDOWN:
                     if event.key == K_r:
                         gameover = False
                         score = 0
                     if event.key == K_ESCAPE:
                         gamedone = True
                         gameover = False
                 if event.type == QUIT:
                     gameover = False
                     gamedone = True
                     
                gameovertext = font.render ("GAME OVER, NUBLET", 1, (255, 255, 255, 255))
                screen.blit (gameovertext, (190, 220))
                gameovertext = font.render ("Press R to restart, ESC to exit", 1, (0, 0, 0, 255))
                screen.blit (gameovertext, (150, 280))
                omfg = font.render ("http://omfg-forums.net", 1, (255, 255, 255, 255))
                screen.blit (omfg, (10, 2))
                scoretext = font.render ("Score: " + str(score), 1, (255, 255, 255, 255))
                screen.blit (scoretext, (10, 25))
        
                pygame.display.flip()
                pygame.display.get_surface().fill ((128, 128, 128))
            
        # draw the text
        omfg = font.render ("http://omfg-forums.net", 1, (255, 255, 255, 255))
        screen.blit (omfg, (10, 2))

        scoretext = font.render ("Score: " + str(score), 1, (255, 255, 255, 255))
        screen.blit (scoretext, (10, 25))

        pygame.display.flip()
        pygame.display.get_surface().fill ((0, 0, 0))

        pygame.time.Clock().tick (120)

        frame += 1
        
main()
