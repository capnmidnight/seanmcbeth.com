# setup.py
from distutils.core import setup
import glob
import py2exe

setup(windows=["main.py"],
      data_files=["readme.txt", "license.txt", "freesansbold.ttf"],
)
