using System;

namespace PlumeModelling
{
	/// <summary>
	/// Summary description for WeatherStation.
	/// </summary>
	public class WeatherStation
	{
		private Vector3D location;
		/// <summary>
		/// Creates a new weather station at a specified grid point
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		public WeatherStation(int x, int y)
		{
			location = new Vector3D(x, y, 0);
		}

		/// <summary>
		/// Gets the current wind vector
		/// </summary>
		public Vector3D Wind
		{
			get
			{
				Random r = new Random();
				return new Vector3D(r.NextDouble()*5.0-2.5, r.NextDouble()*5.0-2.5, 0);
			}
		}

		/// <summary>
		/// Gets the current atmospheric pressure, in millibars
		/// </summary>
		public double Pressure
		{
			get
			{
				return new Random().NextDouble() * 10.0;
			}
		}

		/// <summary>
		/// Gets the current air tempurate, in degrees Farenheit
		/// </summary>
		public double Temperature
		{
			get
			{
				return new Random().NextDouble() * 100.0;
			}
		}
	}
}
