using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Threading;

namespace PlumeModelling
{
	/// <summary>
	/// Summary description for PlumeGenerator.
	/// </summary>
	public class PlumeGenerator
	{
		private double zoom, progress;
		private int gasFlowRate, gasVolume, gasDischargeTime, imgWidth, imgHeight;
		private bool done;
		private Thread thread;
		private Random rand;
		private int[] particleX, particleY;
		private int originX, originY;
		private Bitmap image;
		private VectorField wind;
		public static int particleSize = 20;
		
		public PlumeGenerator(VectorField wind, int fRate, int vol, int time, double zoom)
		{
			this.wind = wind;
			gasFlowRate = fRate;
			gasVolume = vol;
			gasDischargeTime = time;
			this.zoom = zoom;
			rand = new Random();
			particleX = new int[gasVolume];
			particleY = new int[gasVolume];
			done = false;

			thread = new Thread(new ThreadStart(calculate));
			thread.Start();
		}
		private void calculate()
		{
			int gasLeft = gasVolume;
			bool[] alive = new bool[gasVolume];
			int lastAlive = 0;
			double[] x = new double[gasVolume];
			double[] y = new double[gasVolume];
			double[] dx = new double[gasVolume];
			double[] dy = new double[gasVolume];
			int particlesExpelled;
			double expelAngle;
			double expelSpeed;
			
			double minX, minY, maxX, maxY;
			minX = minY = double.MaxValue;
			maxX = maxY = double.MinValue;
			//simulate particles
			for(int i = 0; i < gasDischargeTime; ++i)
			{
				progress = i / (gasDischargeTime+gasVolume);
				//expel new particles
				particlesExpelled = (gasLeft>gasFlowRate)?gasFlowRate:gasLeft;
				if(gasLeft > 0) gasLeft -= gasFlowRate;
				if(gasLeft < 0) gasLeft = 0;
				for(int n = 0; n < particlesExpelled; ++n)
				{
					alive[lastAlive + n] = true;
					x[lastAlive + n] = 0;
					y[lastAlive + n] = 0;

					//give particle random velocity
					expelAngle = rand.NextDouble() * Math.PI * 2;
					expelSpeed = rand.Next(gasFlowRate);
					dx[lastAlive + n] = Math.Cos(expelAngle) * expelSpeed;
					dy[lastAlive + n] = Math.Sin(expelAngle) * expelSpeed;
				}
				lastAlive += particlesExpelled;
				if(lastAlive > gasVolume) lastAlive = gasVolume;
				//blow particles off course
				for(int n = 0; n < lastAlive; ++n)
				{
					dx[n] += wind[x[n], y[n]].X;
					dy[n] += wind[x[n], y[n]].Y;
					x[n] += dx[n];
					y[n] += dy[n];
				}
			}
			for(int i = 0; i < gasVolume; ++i)
			{
				minX = Math.Min(minX, x[i]);
				minY = Math.Min(minY, y[i]);
				maxX = Math.Max(maxX, x[i]);
				maxY = Math.Max(maxY, y[i]);
			}
			progress = 1;
			//save results
			imgWidth = (int)((maxX - minX) * zoom);
			imgHeight =(int)((maxY - minY) * zoom);
			for(int i = 0; i < gasVolume; ++i)
			{
				particleX[i] = (int)((x[i] - minX) * zoom);
				particleY[i] = (int)((y[i] - minY) * zoom);
			}
			originX = (int)(-minX * zoom);
			originY = (int)(-minY * zoom);

			render();
			done=true;
		}

		private void render()
		{
			image = new Bitmap(imgWidth + particleSize, imgHeight + particleSize, PixelFormat.Format32bppArgb);
			Graphics g = Graphics.FromImage(image);
			g.Clear(Color.Black);
			SolidBrush b ;
			Color temp;
			int r, gr, bl;
			for(int i = 0; i < gasVolume; ++i)
			{
				progress = (gasDischargeTime + i) / (gasDischargeTime + gasVolume);
				temp = image.GetPixel(particleX[i], particleY[i]);
				
				//blend
				r = 165 + temp.R;
				if(r > 255) r = 255;
				gr = 55 + temp.G;
				if(gr > 255) gr = 255;
				bl = 35 + temp.B;
				if(bl > 255) bl = 255;
				temp = Color.FromArgb(64, r, gr, bl);

				b = new SolidBrush(temp);
				g.FillEllipse(b, particleX[i], particleY[i], particleSize, particleSize);
				g.Flush();
			}
			g.DrawLine(Pens.Red, originX - 10, originY, originX + 10, originY);
			g.DrawLine(Pens.Red, originX, originY - 10, originX, originY + 10);
			g.Dispose();
		}

		public bool Done
		{
			get
			{
				return this.done;
			}
		}

		public Image Image
		{
			get
			{
				return this.image;
			}
		}
		public int Progress
		{
			get
			{
				return (int)(progress * 100);
			}
		}
	}
}
