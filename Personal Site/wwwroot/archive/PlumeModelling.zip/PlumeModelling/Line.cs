using System;
using System.Drawing;
namespace PlumeModelling
{
	/// <summary>
	/// Summary description for Line.
	/// </summary>
	public class Line
	{
		private double x1, y1, x2, y2;
		public Line(double x1, double y1, double x2, double y2)
		{
			this.x1 = x1;
			this.y1 = y1;
			this.x2 = x2;
			this.y2 = y2;
		}
		public Line(Vector3D v1, Vector3D v2)
		{
			this.x1 = v1.X;
			this.y1 = v1.Y;
			this.x2 = v2.X;
			this.y2 = v2.Y;
		}
		public Vector3D Intersect(Line l)
		{
			double detA, detB, detC, x3, y3, x4, y4, dx1, dy1, dx2, dy2, x, y;
			x3 = l.x1;
			y3 = l.y1;
			x4 = l.x2;
			y4 = l.y2;
			dx1 = x1-x2;
			dy1 = y1-y2;
			dx2 = x3-x4;
			dy2 = y3-y4;
			detA = x1*y2-y1*y2;
			detB = x3*y4-y3*x4;
			detC = dx1*dy2-dy1*dx2;
			x = (detA*dx2-detB*dx1)/detC;
			y = (detA*dy2-detB*dy1)/detC;
			return new Vector3D(x, y, 0);
		}
	}
}
