using System;
using System.Collections;

namespace PlumeModelling
{
	/// <summary>
	/// A 2D grid of Vector3Ds. The VectorField is seeded with a few Vector3Ds, which
	/// are then interpolated across the width and height of the VectorField.
	/// </summary>
	public class VectorField
	{
		Hashtable vectors;
		/// <summary>
		/// Initializes a new VectorField of a given size.
		/// </summary>
		public VectorField()
		{
			vectors = new Hashtable();
		}

		public void Add(Vector3D loc, Vector3D v)
		{
			vectors.Add(loc, v);
		}
	
		public Vector3D this[double x, double y]
		{
			
			get
			{
				IEnumerator en;
				if(vectors.Count == 0)
				{
					return new Vector3D(0, 0, 0);
				}
				if(vectors.Count == 1)
				{
					en = vectors.Values.GetEnumerator();
					en.MoveNext();
					return (Vector3D)en.Current;
				}
				Vector3D temp = new Vector3D(x, y, 0);
				double d1 = double.MaxValue;
				Vector3D v1 = Vector3D.ZERO;
				foreach(Vector3D p in vectors.Keys)
				{
					double dist = (p - temp).Magnitude;
					if(dist < d1)
					{
						d1 = dist;
						v1 = (Vector3D) vectors[p];
					}
				}
				double d2 = double.MaxValue;
				Vector3D v2 = Vector3D.ZERO;
				foreach(Vector3D p in vectors.Keys)
				{
					double dist = (p - temp).Magnitude;
					if(dist < d2 && v1 != (Vector3D) vectors[p])
					{
						d2 = dist;
						v2 = (Vector3D) vectors[p];
					}
				}
				double dt = d1 + d2;
				d1 = (dt - d1)/dt;
				d2 = (dt - d2)/dt;
				return v1*d1 + v2*d2;
			}
		}
	}
}