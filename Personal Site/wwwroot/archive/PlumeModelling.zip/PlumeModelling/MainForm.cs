using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PlumeModelling
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.RadioButton rbDir0;
		private System.Windows.Forms.RadioButton rbDir45;
		private System.Windows.Forms.RadioButton rbDir90;
		private System.Windows.Forms.RadioButton rbDir135;
		private System.Windows.Forms.RadioButton rbDir180;
		private System.Windows.Forms.RadioButton rbDir225;
		private System.Windows.Forms.RadioButton rbDir270;
		private System.Windows.Forms.RadioButton rbDir315;
		private System.Windows.Forms.TrackBar tbSpd;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TrackBar tbRate;
		private System.Windows.Forms.TrackBar tbVol;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TrackBar tbTime;
		private System.Windows.Forms.Button btnGen;
		private System.Windows.Forms.TrackBar tbZoom;
		private System.Windows.Forms.Label label5;

		private double dir, spd, zoom;
		private int vol, flow, time;
		private PlumeGenerator gen;
		private ImageView view;
		private System.Windows.Forms.Button button1;
		private Timer timer;
		private System.Windows.Forms.TextBox txtOutput;
		private VectorField field;
		private ArrayList winds;
		private System.Windows.Forms.TextBox txtX;
		private System.Windows.Forms.TextBox txtY;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button button2;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			dir = Math.PI / 4;
			field = new VectorField();
			timer = new Timer();
			timer.Interval = 250;
			timer.Tick += new EventHandler(timer_Tick);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.rbDir0 = new System.Windows.Forms.RadioButton();
			this.rbDir45 = new System.Windows.Forms.RadioButton();
			this.rbDir90 = new System.Windows.Forms.RadioButton();
			this.rbDir135 = new System.Windows.Forms.RadioButton();
			this.rbDir180 = new System.Windows.Forms.RadioButton();
			this.rbDir225 = new System.Windows.Forms.RadioButton();
			this.rbDir270 = new System.Windows.Forms.RadioButton();
			this.rbDir315 = new System.Windows.Forms.RadioButton();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.btnAdd = new System.Windows.Forms.Button();
			this.tbSpd = new System.Windows.Forms.TrackBar();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.tbRate = new System.Windows.Forms.TrackBar();
			this.label3 = new System.Windows.Forms.Label();
			this.tbVol = new System.Windows.Forms.TrackBar();
			this.label4 = new System.Windows.Forms.Label();
			this.tbTime = new System.Windows.Forms.TrackBar();
			this.btnGen = new System.Windows.Forms.Button();
			this.tbZoom = new System.Windows.Forms.TrackBar();
			this.label5 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.txtOutput = new System.Windows.Forms.TextBox();
			this.txtX = new System.Windows.Forms.TextBox();
			this.txtY = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.btnClear = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.tbSpd)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.tbRate)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.tbVol)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.tbTime)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.tbZoom)).BeginInit();
			this.SuspendLayout();
			// 
			// rbDir0
			// 
			this.rbDir0.Location = new System.Drawing.Point(112, 56);
			this.rbDir0.Name = "rbDir0";
			this.rbDir0.Size = new System.Drawing.Size(40, 24);
			this.rbDir0.TabIndex = 0;
			this.rbDir0.Text = "0�";
			this.rbDir0.CheckedChanged += new System.EventHandler(this.rbDir0_CheckedChanged);
			// 
			// rbDir45
			// 
			this.rbDir45.Checked = true;
			this.rbDir45.Location = new System.Drawing.Point(104, 80);
			this.rbDir45.Name = "rbDir45";
			this.rbDir45.Size = new System.Drawing.Size(40, 24);
			this.rbDir45.TabIndex = 1;
			this.rbDir45.TabStop = true;
			this.rbDir45.Text = "45�";
			this.rbDir45.CheckedChanged += new System.EventHandler(this.rbDir45_CheckedChanged);
			// 
			// rbDir90
			// 
			this.rbDir90.Location = new System.Drawing.Point(64, 96);
			this.rbDir90.Name = "rbDir90";
			this.rbDir90.Size = new System.Drawing.Size(40, 24);
			this.rbDir90.TabIndex = 2;
			this.rbDir90.Text = "90�";
			this.rbDir90.CheckedChanged += new System.EventHandler(this.rbDir90_CheckedChanged);
			// 
			// rbDir135
			// 
			this.rbDir135.Location = new System.Drawing.Point(32, 80);
			this.rbDir135.Name = "rbDir135";
			this.rbDir135.Size = new System.Drawing.Size(48, 24);
			this.rbDir135.TabIndex = 3;
			this.rbDir135.Text = "135�";
			this.rbDir135.CheckedChanged += new System.EventHandler(this.rbDir135_CheckedChanged);
			// 
			// rbDir180
			// 
			this.rbDir180.Location = new System.Drawing.Point(24, 56);
			this.rbDir180.Name = "rbDir180";
			this.rbDir180.Size = new System.Drawing.Size(48, 24);
			this.rbDir180.TabIndex = 4;
			this.rbDir180.Text = "180�";
			this.rbDir180.CheckedChanged += new System.EventHandler(this.rbDir180_CheckedChanged);
			// 
			// rbDir225
			// 
			this.rbDir225.Location = new System.Drawing.Point(32, 32);
			this.rbDir225.Name = "rbDir225";
			this.rbDir225.Size = new System.Drawing.Size(48, 24);
			this.rbDir225.TabIndex = 5;
			this.rbDir225.Text = "225�";
			this.rbDir225.CheckedChanged += new System.EventHandler(this.rbDir225_CheckedChanged);
			// 
			// rbDir270
			// 
			this.rbDir270.Location = new System.Drawing.Point(64, 16);
			this.rbDir270.Name = "rbDir270";
			this.rbDir270.Size = new System.Drawing.Size(48, 24);
			this.rbDir270.TabIndex = 6;
			this.rbDir270.Text = "270�";
			this.rbDir270.CheckedChanged += new System.EventHandler(this.rbDir270_CheckedChanged);
			// 
			// rbDir315
			// 
			this.rbDir315.Location = new System.Drawing.Point(104, 32);
			this.rbDir315.Name = "rbDir315";
			this.rbDir315.Size = new System.Drawing.Size(48, 24);
			this.rbDir315.TabIndex = 7;
			this.rbDir315.Text = "315�";
			this.rbDir315.CheckedChanged += new System.EventHandler(this.rbDir315_CheckedChanged);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.txtY);
			this.groupBox1.Controls.Add(this.txtX);
			this.groupBox1.Controls.Add(this.rbDir0);
			this.groupBox1.Controls.Add(this.rbDir90);
			this.groupBox1.Controls.Add(this.rbDir315);
			this.groupBox1.Controls.Add(this.rbDir225);
			this.groupBox1.Controls.Add(this.rbDir45);
			this.groupBox1.Controls.Add(this.rbDir135);
			this.groupBox1.Controls.Add(this.rbDir270);
			this.groupBox1.Controls.Add(this.rbDir180);
			this.groupBox1.Controls.Add(this.btnAdd);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.tbSpd);
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(160, 208);
			this.groupBox1.TabIndex = 8;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Wind";
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(104, 176);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(48, 24);
			this.btnAdd.TabIndex = 21;
			this.btnAdd.Text = "Add";
			this.btnAdd.Click += new System.EventHandler(this.button2_Click);
			// 
			// tbSpd
			// 
			this.tbSpd.LargeChange = 10;
			this.tbSpd.Location = new System.Drawing.Point(8, 136);
			this.tbSpd.Maximum = 100;
			this.tbSpd.Name = "tbSpd";
			this.tbSpd.Size = new System.Drawing.Size(144, 45);
			this.tbSpd.TabIndex = 9;
			this.tbSpd.TickFrequency = 5;
			this.tbSpd.Value = 2;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 120);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 16);
			this.label1.TabIndex = 10;
			this.label1.Text = "Wind Speed";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(176, 8);
			this.label2.Name = "label2";
			this.label2.TabIndex = 8;
			this.label2.Text = "Gas Flow Rate";
			// 
			// tbRate
			// 
			this.tbRate.Location = new System.Drawing.Point(176, 32);
			this.tbRate.Name = "tbRate";
			this.tbRate.Size = new System.Drawing.Size(104, 45);
			this.tbRate.TabIndex = 11;
			this.tbRate.Value = 9;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(176, 80);
			this.label3.Name = "label3";
			this.label3.TabIndex = 12;
			this.label3.Text = "Gas Volume";
			// 
			// tbVol
			// 
			this.tbVol.Location = new System.Drawing.Point(176, 104);
			this.tbVol.Name = "tbVol";
			this.tbVol.Size = new System.Drawing.Size(104, 45);
			this.tbVol.TabIndex = 13;
			this.tbVol.Value = 7;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(176, 144);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(112, 23);
			this.label4.TabIndex = 14;
			this.label4.Text = "Gas Discharge Time";
			// 
			// tbTime
			// 
			this.tbTime.Location = new System.Drawing.Point(176, 168);
			this.tbTime.Maximum = 20;
			this.tbTime.Name = "tbTime";
			this.tbTime.Size = new System.Drawing.Size(104, 45);
			this.tbTime.TabIndex = 15;
			this.tbTime.Value = 8;
			// 
			// btnGen
			// 
			this.btnGen.Location = new System.Drawing.Point(184, 216);
			this.btnGen.Name = "btnGen";
			this.btnGen.TabIndex = 16;
			this.btnGen.Text = "Generate";
			this.btnGen.Click += new System.EventHandler(this.btnGen_Click);
			// 
			// tbZoom
			// 
			this.tbZoom.Location = new System.Drawing.Point(104, 248);
			this.tbZoom.Maximum = 5;
			this.tbZoom.Name = "tbZoom";
			this.tbZoom.Size = new System.Drawing.Size(64, 45);
			this.tbZoom.TabIndex = 17;
			this.tbZoom.Value = 1;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(112, 224);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(40, 23);
			this.label5.TabIndex = 18;
			this.label5.Text = "Zoom";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(184, 248);
			this.button1.Name = "button1";
			this.button1.TabIndex = 19;
			this.button1.Text = "Loop";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// txtOutput
			// 
			this.txtOutput.AcceptsReturn = true;
			this.txtOutput.Location = new System.Drawing.Point(280, 8);
			this.txtOutput.Multiline = true;
			this.txtOutput.Name = "txtOutput";
			this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtOutput.Size = new System.Drawing.Size(296, 280);
			this.txtOutput.TabIndex = 20;
			this.txtOutput.Text = "";
			this.txtOutput.WordWrap = false;
			// 
			// txtX
			// 
			this.txtX.Location = new System.Drawing.Point(40, 176);
			this.txtX.Name = "txtX";
			this.txtX.Size = new System.Drawing.Size(32, 20);
			this.txtX.TabIndex = 22;
			this.txtX.Text = "0";
			// 
			// txtY
			// 
			this.txtY.Location = new System.Drawing.Point(72, 176);
			this.txtY.Name = "txtY";
			this.txtY.Size = new System.Drawing.Size(32, 20);
			this.txtY.TabIndex = 23;
			this.txtY.Text = "0";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 176);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(32, 16);
			this.label6.TabIndex = 24;
			this.label6.Text = "Loc:";
			// 
			// btnClear
			// 
			this.btnClear.Location = new System.Drawing.Point(184, 280);
			this.btnClear.Name = "btnClear";
			this.btnClear.TabIndex = 21;
			this.btnClear.Text = "Clear ->";
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(8, 224);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 32);
			this.button2.TabIndex = 22;
			this.button2.Text = "Test Wind Field";
			this.button2.Click += new System.EventHandler(this.button2_Click_1);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(586, 304);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.txtOutput);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.tbZoom);
			this.Controls.Add(this.btnGen);
			this.Controls.Add(this.tbTime);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.tbVol);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.tbRate);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.label2);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "Form1";
			this.Text = "ParticleGen";
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.tbSpd)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.tbRate)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.tbVol)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.tbTime)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.tbZoom)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnGen_Click(object sender, System.EventArgs e)
		{
			flow = tbRate.Value;
			vol = tbVol.Value * 100;
			time = tbTime.Value * 15;
			zoom = tbZoom.Value / 10.0;
			gen = new PlumeGenerator(field, flow, vol, time, zoom);
			while(!gen.Done)
			{
				Application.DoEvents();
			}
			if(view == null)
			{
				view = new ImageView(gen.Image);	
			}
			else
			{
				view.Image = gen.Image;
			}
			view.Visible = true;
		}

		private void rbDir0_CheckedChanged(object sender, System.EventArgs e)
		{
			dir = 0;
		}

		private void rbDir45_CheckedChanged(object sender, System.EventArgs e)
		{
			dir = Math.PI / 4;
		}

		private void rbDir90_CheckedChanged(object sender, System.EventArgs e)
		{
			dir = Math.PI / 2;
		}

		private void rbDir135_CheckedChanged(object sender, System.EventArgs e)
		{
			dir = Math.PI * 3 / 4;
		}

		private void rbDir180_CheckedChanged(object sender, System.EventArgs e)
		{
			dir = Math.PI;
		}

		private void rbDir225_CheckedChanged(object sender, System.EventArgs e)
		{
			dir = Math.PI * 5 / 4;
		}

		private void rbDir270_CheckedChanged(object sender, System.EventArgs e)
		{
			dir = Math.PI * 3 / 2;
		}

		private void rbDir315_CheckedChanged(object sender, System.EventArgs e)
		{
			dir = Math.PI * 7 / 4;
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			tbTime.Value = 0;
			timer.Enabled = true;
		}

		private void timer_Tick(object sender, EventArgs e)
		{
			timer.Enabled = false;
			btnGen_Click(null, null);
			timer.Enabled = true;
			if(tbTime.Value < tbTime.Maximum)
			{
				tbTime.Value++;
			}
			else
			{
				timer.Enabled = false;
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			int x = int.Parse(txtX.Text);
			int y = int.Parse(txtY.Text);
			spd = tbSpd.Value / 50.0;
			Vector3D v = new Vector3D(Math.Cos(dir) * spd, Math.Sin(dir) * spd, 0);
			txtOutput.Text += string.Format("({0},{1}):{2}\r\n", x, y, v.ToString());
			field.Add(new Vector3D(x, y, 0), v);
		}

		private void btnClear_Click(object sender, System.EventArgs e)
		{
			field = new VectorField();
			txtOutput.Text = "";
		}

		private void button2_Click_1(object sender, System.EventArgs e)
		{
			double x = double.Parse(txtX.Text);
			double y = double.Parse(txtY.Text);
			Vector3D v = field[x, y];
			txtOutput.Text += v.ToString() + "\r\n";
		}
	}
}
