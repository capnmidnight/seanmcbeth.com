using System;
namespace PlumeModelling
{
	/// <summary>
	/// A 3 component vector for positioning and moving objects in 3-space
	/// </summary>
	public struct Vector3D
	{
		public static Vector3D ZERO = new Vector3D(0, 0, 0);
		private double x, y, z;
		/// <summary>
		/// Initializes a new vector with the supplied component values
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <param name="z"></param>
		public Vector3D(double x, double y, double z)
		{
			this.x = x;
			this.y = y;
			this.z = z;
		}
		public double X{get{return x;}set{x=value;}}
		public double Y{get{return y;}set{y=value;}}
		public double Z{get{return z;}set{z=value;}}
		public double Magnitude{get{return Math.Sqrt(x*x+y*y+z*z);}}
		public override string ToString()
		{
			return string.Format("<{0}, {1}, {2}>", x, y, z);
		}

		public static Vector3D operator+(Vector3D a, Vector3D b)
		{
			return new Vector3D(a.x + b.x, a.y + b.y, a.z + b.z);
		}
		public static Vector3D operator*(Vector3D a, double b)
		{
			return new Vector3D(a.x * b, a.y * b, a.z * b);
		}
		public static Vector3D operator-(Vector3D a, Vector3D b)
		{
			return new Vector3D(a.x - b.x, a.y - b.y, a.z - b.z);
		}
		public static bool operator== (Vector3D a, Vector3D b)
		{
			return !(a!=b);
		}
		public static bool operator!= (Vector3D a, Vector3D b)
		{
			Vector3D temp = a - b;
			return temp.X != 0.0 || temp.Y != 0.0 || temp.Z != 0.0;
		}
	}
}
