3HGDC V Entry

by matt_j

Website: www.brilliant-bytes.com
E-Mail:  matt_j@shaw.ca

How to play:

Left and Right - move back and forth
Mouse button - shoot at location the pointer is pointing at
Esc - quits the game (from the intro screen), escape to intro (from the game)

Release notes:

0.9 - 3HGDC release