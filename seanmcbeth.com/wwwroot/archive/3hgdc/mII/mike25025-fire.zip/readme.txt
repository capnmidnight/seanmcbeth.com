Controls:
Left,Right - Slide
Up - Jump
Esc - Quit

I didnt have enough time to add score or restart so you cant play again without first quiting the game. I didnt get much done :(