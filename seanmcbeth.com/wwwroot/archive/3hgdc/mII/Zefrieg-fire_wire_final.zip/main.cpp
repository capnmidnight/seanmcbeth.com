/*/////////////////////////////////////////////////////////////////////////////
Programmer: Jacob Ensign
GDnet ID: Zefrieg
Email: Ultamos@msn.com or jbeyqf@umkc.edu
Description:

	Game for 3 hour contest.

/////////////////////////////////////////////////////////////////////////////*/
#include <allegro.h>
#include <cmath>
#include <ctime>
#include <list>

BITMAP* back_buffer = 0;
BITMAP* video_buffer = 0;
int screen_width = 0;
int screen_height = 0;
int white = 0;
clock_t last_time = 0;
clock_t current_time = 0;

// Constants
const int FIRE_WIDTH = 256;
const int FIRE_HEIGHT = 256;

// Game Data
BITMAP* left_beam = 0;
BITMAP* right_beam = 0;
BITMAP* fire = 0;
BITMAP* guy_walk[2];
BITMAP* guy_fall[2];
BITMAP* rock;
unsigned long fire_colors[256];
unsigned char fire_array[FIRE_WIDTH * FIRE_HEIGHT];

#define ERROR(x) alert(x, "Press Enter to Continue.", 0, "OK", 0, KEY_ENTER, 0)
#define MOUSE_LEFT (mouse_b & 1)
#define MOUSE_RIGHT (mouse_b & 2)
#define KEY(x) key[x]

struct vector2d
{
	float x;
	float y;
	vector2d(): x(0.0f), y(0.0f) { }
};

struct guy
{
	vector2d position;
	vector2d velocity;
	float balance;
	int frame;
	bool falling;
	guy(): balance(0.0f), frame(0), falling(false) { }
};

struct boulder
{
	vector2d position;
	vector2d velocity;
};

void init_graphics(int width, int height, int bpp)
{
	screen_width = width;
	screen_height = height;
	set_color_depth(bpp);
	set_gfx_mode(GFX_AUTODETECT_WINDOWED, width, height, 0, 0);
	video_buffer = create_video_bitmap(width, height);
	if(video_buffer == screen)
	{
		back_buffer = create_video_bitmap(width, height);
	}
	else
	{
		back_buffer = video_buffer;
	}
}

void clear_back_buffer()
{
	clear_bitmap(back_buffer);
}

void flip()
{
	vsync();
	blit(back_buffer, video_buffer, 0, 0, 0, 0, screen_width, screen_height);
}

void clear_graphics()
{
	if(back_buffer)
	{
		destroy_bitmap(back_buffer);
		back_buffer = 0;
	}
	if(video_buffer)
	{
		destroy_bitmap(video_buffer);
		video_buffer = 0;
	}
	screen_width = 0;
	screen_height = 0;
}

void text(char* str, int x, int y, int color)
{
	textout(back_buffer, font, str, x, y, color);
}

void init_fire()
{
	BITMAP* bmp;
	bmp = load_bmp("fire.bmp", 0);
	int color;

	for(int i = 0; i < 16; i++)
	{
		for(int j = 0; j < 16; j++)
		{
			color = ((long*)bmp->line[i])[j];
			fire_colors[j + (16 * i)] = color;
		}
	}	

	for(int i = 0; i < FIRE_HEIGHT; i++)
	{
		for(int j = 0; j < FIRE_HEIGHT; j++)
		{
			fire_array[j + (FIRE_WIDTH) * i] = 0;
		}
	}
	
	fire = create_system_bitmap(FIRE_WIDTH, FIRE_HEIGHT);
	clear_bitmap(fire);

	destroy_bitmap(bmp);
}

void clear_fire()
{
	destroy_bitmap(fire);
	fire = 0;
}

void update_fire()
{
	int memory_step = 0;
	int index = 0;
	
	memory_step = FIRE_WIDTH * (FIRE_HEIGHT - 1);
	for(int x = 0; x < FIRE_WIDTH; x++)
	{
		fire_array[x + memory_step] = 255 - (rand() & 255);
	}

	memory_step = 0;

	for(int y = 0; y < FIRE_HEIGHT - 1; y++)
	{
		for(int x = 0; x < FIRE_WIDTH; x++)
		{
			index = x + memory_step;
			if(fire_array[index + FIRE_WIDTH] > 4)
			{
				fire_array[index] = (((fire_array[index + FIRE_WIDTH] << 1) + fire_array[index + FIRE_WIDTH - 1] + fire_array[index + FIRE_WIDTH + 1]) >> 2) - 1;
			}
		}
		memory_step += FIRE_WIDTH;
	}

	unsigned char* ptr_fire_array = fire_array;
	
	acquire_bitmap(fire);
	for(int i = 0; i < FIRE_HEIGHT; i++)
	{
		for(int j = 0; j < FIRE_WIDTH; j++)
		{
			((long*)fire->line[i])[j] = fire_colors[*ptr_fire_array];
			ptr_fire_array++;
		}
	}
	release_bitmap(fire);
}

void blit_fire()
{
	masked_stretch_blit(fire, back_buffer, 0, 0, fire->w, fire->h - 1, 0, 0, screen_width, screen_height);	
}

void blit_player(guy& player)
{
	if(player.falling)
	{
		masked_blit(guy_fall[player.frame], back_buffer, 0, 0, player.position.x, player.position.y, guy_fall[player.frame]->w, guy_fall[player.frame]->h);	
	}
	else
	{
		masked_blit(guy_walk[player.frame], back_buffer, 0, 0, player.position.x, player.position.y, guy_fall[player.frame]->w, guy_walk[player.frame]->h);
		circle(back_buffer, player.position.x - 20, player.position.y + player.balance + 32 , 10, white);
		circle(back_buffer, player.position.x + 20 + 64, player.position.y - player.balance + 32, 10, white);
	}
}

void update_player(guy& player)
{
	float interpolation = 1.0f / float(current_time - last_time);

	if(!player.falling)
	{
		if(player.position.x > 40.0f)
		{
			if(KEY(KEY_LEFT))
			{
				player.velocity.x -= 3.0 * interpolation;
				if(player.frame)
				{
					player.frame = 0;
				}
				else
				{
					player.frame = 1;
				}
			}
		}
		if(player.position.y < 760.0f)
		{
			if(KEY(KEY_RIGHT))
			{
				player.velocity.x += 3.0 * interpolation; 
				if(player.frame)
				{
					player.frame = 0;
				}
				else
				{
					player.frame = 1;
				}
			}
		}
		if(KEY(KEY_UP))
		{
			player.balance += 1.0 * interpolation;
		}
		if(KEY(KEY_DOWN))
		{
			player.balance -= 1.0 * interpolation;
		}
	}
	else
	{
		player.velocity.y += 3.0 * interpolation;
		player.velocity.x = 0;
		if(player.frame)
		{
			player.frame = 0;
		}
		else
		{
			player.frame = 1;
		}
	}

	player.balance += player.velocity.x * interpolation;
	if(player.balance > 10.0f || player.balance < -10.0f)
	{	
		player.falling = true;	
	}
	if(player.position.x < 40.0f)
	{
		player.velocity.x = 0.0f;
		player.position.x = 41.0f;
	}
	else if(player.position.x > 700.0f)
	{
		player.velocity.x = 0.0f;
		player.position.x = 699.0f;
	}
	player.position.x += player.velocity.x;
	player.position.y += player.velocity.y;
}

bool is_collision(float x1, float y1, float x2, float y2,
				  float x3, float y3, float x4, float y4)
{
	return (y1 < y4) && (y3 < y2) && (x1 < x4) && (x3 < x2);
}

int main()
{
	guy player;
	boulder boulders[10];
	

	allegro_init();    
	init_graphics(800, 600, 32);
	install_sound(255, 255, 0);
	set_volume(128, 128);
	install_keyboard();
	install_mouse();
	text_mode(-1);
	init_fire();

	left_beam = load_bmp("wood_01.bmp", 0);
	right_beam = load_bmp("wood_02.bmp", 0);
	guy_walk[0] = load_bmp("guy_01.bmp", 0);
	guy_walk[1] = load_bmp("guy_02.bmp", 0);
	guy_fall[0] = load_bmp("guy_03.bmp", 0);
	guy_fall[1] = load_bmp("guy_04.bmp", 0);
	rock = load_bmp("rock.bmp", 0);
	
	white = makecol(255,255,255);

	player.position.x = 50.0f;
	player.position.y = 112.0f;

	for(int i = 0; i < 10; i++)
	{
		boulders[i].position.x = rand() % 760;
		boulders[i].position.y = -500;
		boulders[i].velocity.y = 20 + rand() % 40;
	}

	while(!KEY(KEY_ESC))
	{
		last_time = current_time;
		current_time = clock();

		float interpolation = 1.0f / float(current_time - last_time);

		update_player(player);
		update_fire();

		for(int i = 0; i < 10; i++)
		{
			if(boulders[i].position.y > 620)
			{
				boulders[i].position.y = -500;
				boulders[i].position.x = rand() % 760;
			}
			boulders[i].position.y += boulders[i].velocity.y * interpolation;
			if(is_collision(boulders[i].position.x + 5, boulders[i].position.y + 5, boulders[i].position.x + rock->w - 5, boulders[i].position.y + rock->h - 5,
				player.position.x + 5, player.position.y + 5, player.position.x + guy_walk[0]->w - 5, player.position.y + guy_walk[0]->h - 5))
			{
				player.falling = true;
			}
		}

		clear_back_buffer();
		blit_fire();
		blit(left_beam, back_buffer, 0, 0, 20, 170, left_beam->w, left_beam->h);
		blit(right_beam, back_buffer, 0, 0, 760, 170, right_beam->w, right_beam->h);
		blit_player(player);
		for(int i = 0; i < 10; i++)
		{
			masked_blit(rock, back_buffer, 0, 0, boulders[i].position.x, boulders[i].position.y, rock->w, rock->h); 
		}
        line(back_buffer, 38, 178, 762, 178, white);

		flip();
	}

	clear_fire();
	destroy_bitmap(rock);
	destroy_bitmap(guy_walk[0]);
	destroy_bitmap(guy_walk[1]);
	destroy_bitmap(guy_fall[0]);
	destroy_bitmap(guy_fall[1]);
	destroy_bitmap(left_beam);
	destroy_bitmap(right_beam);
	clear_graphics();
	remove_sound();
	remove_keyboard();
	remove_mouse();
	return 0;
}

END_OF_MAIN()