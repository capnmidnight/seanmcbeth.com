Crackers! version 0.21
----------------------
Made for the Three Hour Game Development Contest
hosted by capn_midnight on the GameDev.net forums
by
Snaily
with
Python 2.4, pygame and py2exe (may it burn in hell).

I had originally written a long and witty post-mortem here. I accidentally deleted it. Somehow, I find it fitting, though.
You only need to know the controls:
Mouse aims,
LMB down fires a cracker that
LMB up explodes.
You move around by using the recoil from the crackers as well as the (invisible) blasts.
There's nothing else to do: I intended to add randomly spawning crackers like asteroids, but time was not on my side.

Snaily