// PirateBurninator.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#include "directxbase.h"

int __stdcall WinMain(HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    int nCmdShow)
{
	DirectXBase *dxbase = new DirectXBase(hInstance);

	dxbase->Init(FALSE, 32, 1024, 768);

	dxbase->Run();

	dxbase->Shutdown();

	return 0;
}