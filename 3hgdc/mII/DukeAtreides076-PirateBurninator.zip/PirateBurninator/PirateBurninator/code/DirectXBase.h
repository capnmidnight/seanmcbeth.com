#pragma once

#define KEYDOWN(x) ((GetAsyncKeyState(x)&0x8000) ? 1 : 0)
#define KEYUP(x) ((GetAsyncKeyState(x)&0x8000) ? 0 : 1)

struct Pirate
{
	float x;
	float y;
	float xvel;
	float yvel;
	float health;
};

struct Fireball
{
	float x;
	float y;
	float rot;
};

class DirectXBase
{
public:

	DirectXBase(HINSTANCE);
	~DirectXBase();

	// creation and deletion
	BOOL Init(BOOL windowed, int BPP, int Width, int Height);
	void Shutdown(void);

	INT Run();

	// Accessors
	LPDIRECT3DDEVICE9 GetDevice(){return m_pd3dDevice;}

	// generic window handler
	static LRESULT CALLBACK DispatchWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
	{
		if (message == WM_NCCREATE)
		{
			CREATESTRUCT* cs = (CREATESTRUCT*)lParam;
			SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)cs->lpCreateParams);

			return TRUE;
		}
		else
		{
			DirectXBase *app = (DirectXBase*)GetWindowLongPtr(hWnd, GWLP_USERDATA);

			if (app!=NULL)
				return app->WndProc(hWnd, message, wParam, lParam);
			else
				return DefWindowProc(hWnd, message, wParam, lParam); 
		}
	}

	void InitGame();

	// class window handler
	LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

	// drawing
	void Draw2D(LPDIRECT3DTEXTURE9 tex, RECT src, RECT dest, D3DCOLOR mod);
	void Draw2D(LPDIRECT3DTEXTURE9 tex, RECT src, RECT dest, float rot, D3DCOLOR mod);

private:
	BOOL bWindowed; // window mode
	int  iBpp;		// color depth
	int	 iWidth;	// window width
	int	 iHeight;   // window height

	int state;
	int sel;

	HWND hWnd;		// device window
	HINSTANCE hInst;// application instance


	// PIRATES!1
	void AddPirate();
	void ClearPirates();
	void RunPirates(DWORD);

	// fireball
	void FireWeapon();
	void ClearFireballs();
	void RunFireballs(DWORD);

	void Explode(int, int);
	void ClearExplosions();
	void RunExplosions(DWORD);


	// Direct3D objects
	LPDIRECT3D9 m_pD3D;
	LPDIRECT3DDEVICE9 m_pd3dDevice;

	LPD3DXSPRITE m_sprite;

	// font
	LPD3DXFONT menu;			// font object for the menu text


	// intialization flag
	BOOL bInit;

	// windowing functions
	ATOM				RegisterClass(HINSTANCE);
	BOOL				InitInstance();

	// happy text
	char szWindowClass[32];
	char szTitle[32];


	/////// game variables
	LPDIRECT3DTEXTURE9 water;
	LPDIRECT3DTEXTURE9 ship;
	LPDIRECT3DTEXTURE9 pirate;
	LPDIRECT3DTEXTURE9 fire;
	LPDIRECT3DTEXTURE9 fireball;

	LPD3DXFONT gtext;

	std::vector<Pirate*> pirates;
	std::vector<Fireball*> fireballs;
	std::vector<Fireball*> explosions;

	int wshift;

	float sx;
	float sy;

	float score;
	float firedelay;
};

class ExplosionRemove : std::unary_function<Fireball*, bool>
{
public:
	bool operator()(Fireball*& exp) const
	{
		return (exp->rot > D3DX_PI*20);
	}
};

class FireballRemove : std::unary_function<Fireball*, bool>
{
public:
	bool operator()(Fireball*& exp) const
	{
		return (exp->x < -64);
	}
};

class PirateRemove : std::unary_function<Pirate*, bool>
{
public:
	bool operator()(Pirate*& exp) const
	{
		return (exp->health == 0 || exp->x > 1200 || exp->y > 850);
	}
};
