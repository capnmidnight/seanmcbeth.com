// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


#include <iostream>
#include <tchar.h>

// TODO: reference additional headers your program requires here

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <vector>
#include <ctime>
#include <functional>
#include <algorithm>
