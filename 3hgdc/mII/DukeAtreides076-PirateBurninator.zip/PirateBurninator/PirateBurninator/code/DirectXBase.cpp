#include "StdAfx.h"
#include ".\directxbase.h"

DirectXBase::DirectXBase(HINSTANCE hInstance)
{
	bInit = FALSE;

	// Set pointers to NULL in case something goes wrong
	m_pd3dDevice = NULL;
	m_pD3D = NULL;

	hWnd = NULL;
	hInst = hInstance;

	strcpy(szWindowClass,"burninate");
	strcpy(szTitle,"PIRATE BURNINATOR");

	state=-1;
	sel = 0;
}

DirectXBase::~DirectXBase(void)
{
}

BOOL DirectXBase::Init(BOOL windowed, int BPP, int Width, int Height)
{
	// Return Value: TRUE if succeeded, else FALSE

	srand((unsigned)time(NULL));
	bWindowed = windowed;
	iBpp = BPP;
	iWidth = Width;
	iHeight = Height;

	// set up the window
	RegisterClass(hInst);

	// Perform application initialization:
	if (!InitInstance ()) 
	{
		bInit = FALSE;
		return FALSE;
	}

	// start up Direct3d
	if( NULL == ( m_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
		return FALSE;

	// fill up the present parameters
	D3DPRESENT_PARAMETERS d3dpp; 
	
	ZeroMemory( &d3dpp, sizeof(d3dpp) );
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.Windowed = bWindowed;
	d3dpp.hDeviceWindow = hWnd;

	// stencil depth and things
	// Uncomment for depth stencil
	d3dpp.EnableAutoDepthStencil = FALSE;
	//d3dpp.EnableAutoDepthStencil = TRUE;
    //d3dpp.AutoDepthStencilFormat = D3DFMT_D24X8;


	// Dont wait for the vertical retrace
	d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	// check if its running windowed or fullscreen
	if (bWindowed)
	{
		// we dont need to do much here
		d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
		d3dpp.Windowed = TRUE;
	}
	else 
	{
		// initial setup
		d3dpp.Windowed = FALSE;		

		// get the color depth
		if (iBpp == 32 || iBpp == 24)
			d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
		else if (iBpp == 16)
			d3dpp.BackBufferFormat = D3DFMT_R5G6B5;
		else return FALSE;

		// set the requested size
		d3dpp.BackBufferHeight = iHeight;
		d3dpp.BackBufferWidth  = iWidth;

		// now we need to check if the display mode is supported
		D3DDISPLAYMODE d3ddm;
		BOOL bSupported=FALSE;

		// loop through the available adapter modes
		UINT count=m_pD3D->GetAdapterModeCount(D3DADAPTER_DEFAULT, d3dpp.BackBufferFormat);

		for(UINT i=0; i<count; i++)
		{
			if( FAILED(m_pD3D->EnumAdapterModes(D3DADAPTER_DEFAULT,
											d3dpp.BackBufferFormat,
											i, &d3ddm)))
				return FALSE;

			// check and see if it matches our settings
			if (d3ddm.Height == d3dpp.BackBufferHeight && 
				d3ddm.Width  == d3dpp.BackBufferWidth)
			{
				bSupported = TRUE; // its a match, break out of the loop
				break;
			}
		}

		// Check for hardware support
		if(FAILED( m_pD3D->CheckDeviceType(D3DADAPTER_DEFAULT, 
                                        D3DDEVTYPE_HAL, 
                                        d3dpp.BackBufferFormat, 
                                        d3dpp.BackBufferFormat, 
										d3dpp.Windowed)))

			return FALSE;

		if(!bSupported)    // we didnt find the right mode, call fails
			return FALSE;
	}



	// Create the device
	if( FAILED( m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
								D3DCREATE_SOFTWARE_VERTEXPROCESSING,
								&d3dpp, &m_pd3dDevice ) ) )
		return FALSE;


	// sprite
	if (FAILED(D3DXCreateSprite(GetDevice(),&m_sprite)))
		return FALSE;

	// menu font
	if( FAILED(D3DXCreateFont( m_pd3dDevice,          // D3D device
                        72,						// Height
                        0,                     // Width
                        FW_NORMAL,               // Weight
                        0,                     // MipLevels, 0 = autogen mipmaps
                        FALSE,                 // Italic
                        DEFAULT_CHARSET,       // CharSet
                        OUT_DEFAULT_PRECIS,    // OutputPrecision
                        DEFAULT_QUALITY,       // Quality
                        DEFAULT_PITCH | FF_DONTCARE, // PitchAndFamily
                        "Castellar",              // pFaceName
                        &menu)))              // ppFont
		return FALSE;

	if( FAILED(D3DXCreateFont( m_pd3dDevice,          // D3D device
                        24,						// Height
                        0,                     // Width
                        FW_NORMAL,               // Weight
                        0,                     // MipLevels, 0 = autogen mipmaps
                        FALSE,                 // Italic
                        DEFAULT_CHARSET,       // CharSet
                        OUT_DEFAULT_PRECIS,    // OutputPrecision
                        DEFAULT_QUALITY,       // Quality
                        DEFAULT_PITCH | FF_DONTCARE, // PitchAndFamily
                        "Castellar",              // pFaceName
                        &gtext)))              // ppFont
		return FALSE;

	if (FAILED(D3DXCreateTextureFromFile(m_pd3dDevice,"media\\water.dds", &water)))
		return FALSE;

	if (FAILED(D3DXCreateTextureFromFile(m_pd3dDevice,"media\\ship.dds", &ship)))
		return FALSE;

	D3DLOCKED_RECT rout;
	RECT rin = {0,0,64,64};

	if (FAILED(ship->LockRect(0, &rout, &rin, 0)))
		return FALSE;
	
	for (int x=0; x<rin.right; x++)
		for (int y=0; y<rin.bottom; y++)
			if (((DWORD*)((BYTE*)rout.pBits+rout.Pitch*y))[x] == 0xff000000)
				((DWORD*)((BYTE*)rout.pBits+rout.Pitch*y))[x] = D3DCOLOR_ARGB(0,0,0,0);

	ship->UnlockRect(0);

	if (FAILED(D3DXCreateTextureFromFile(m_pd3dDevice,"media\\pirate.dds", &pirate)))
		return FALSE;

	if (FAILED(pirate->LockRect(0, &rout, &rin, 0)))
		return FALSE;
	
	for (int x=0; x<rin.right; x++)
		for (int y=0; y<rin.bottom; y++)
			if (((DWORD*)((BYTE*)rout.pBits+rout.Pitch*y))[x] == 0xff000000)
				((DWORD*)((BYTE*)rout.pBits+rout.Pitch*y))[x] = D3DCOLOR_ARGB(0,0,0,0);

	pirate->UnlockRect(0);

	///
	if (FAILED(D3DXCreateTextureFromFile(m_pd3dDevice,"media\\fire.dds", &fire)))
		return FALSE;

	if (FAILED(fire->LockRect(0, &rout, &rin, 0)))
		return FALSE;
	
	for (int x=0; x<rin.right; x++)
		for (int y=0; y<rin.bottom; y++)
			if (((DWORD*)((BYTE*)rout.pBits+rout.Pitch*y))[x] == 0xff000000)
				((DWORD*)((BYTE*)rout.pBits+rout.Pitch*y))[x] = D3DCOLOR_ARGB(0,0,0,0);

	fire->UnlockRect(0);

	///
	if (FAILED(D3DXCreateTextureFromFile(m_pd3dDevice,"media\\fireball.dds", &fireball)))
		return FALSE;

	if (FAILED(fireball->LockRect(0, &rout, &rin, 0)))
		return FALSE;
	
	for (int x=0; x<rin.right; x++)
		for (int y=0; y<rin.bottom; y++)
			if (((DWORD*)((BYTE*)rout.pBits+rout.Pitch*y))[x] == 0xff000000)
				((DWORD*)((BYTE*)rout.pBits+rout.Pitch*y))[x] = D3DCOLOR_ARGB(0,0,0,0);

	fireball->UnlockRect(0);

	ShowCursor(FALSE);

	bInit = TRUE;
	return bInit;
}

void DirectXBase::AddPirate()
{
	Pirate *p = new Pirate();

	p->health = 100;
	p->x = rand()%1024;
	p->y = -64;

	p->xvel = ((rand()%1000)/1000.0f) * .4f-.2f;
	p->yvel = ((rand()%1000)/1000.0f) * .75f;

	this->pirates.push_back(p);
}

void DirectXBase::ClearPirates()
{
	for (std::vector<Pirate*>::iterator it = pirates.begin() ; 
		it != pirates.end( ) ; )
	{
		Pirate* p = (*it);
		delete p;
		it++;
	}


	// clear
	pirates.clear();
}

void DirectXBase::ClearFireballs()
{
	for (std::vector<Fireball*>::iterator it = fireballs.begin() ; 
		it != fireballs.end( ) ; )
	{
		Fireball* p = (*it);
		delete p;
		it++;
	}


	// clear
	fireballs.clear();
}

void DirectXBase::ClearExplosions()
{
	for (std::vector<Fireball*>::iterator it = explosions.begin() ; 
		it != explosions.end( ) ; )
	{
		Fireball* p = (*it);
		delete p;
		it++;
	}


	// clear
	explosions.clear();
}

void DirectXBase::RunPirates(DWORD delta)
{
	pirates.erase(std::remove_if(pirates.begin(), pirates.end(), PirateRemove()),pirates.end());

	for (std::vector<Pirate*>::iterator it = pirates.begin() ; 
		it != pirates.end( ) ; )
	{
		Pirate* p = (*it);
		p->x += delta * p->xvel;
		p->y += delta * p->yvel;


		// TODO: COLLISION

		if (p->x > sx && p->x < sx+64
	     && p->y > sy && p->y < sy+64)
			state = 2;
		if (p->x+64 > sx && p->x+64 < sx+64
	        && p->y > sy && p->y < sy+64)
			state = 2;
		if (p->x+64 > sx && p->x+64 < sx+64
	        && p->y+64 > sy && p->y+64 < sy+64)
			state = 2;
		if (p->x > sx && p->x < sx+64
	        && p->y+64 > sy && p->y+64 < sy+64)
			state = 2;
		
		RECT ps = {0,0,64,64};
		RECT pd;
		pd.top = (int)p->y;
		pd.left = (int)p->x;
		pd.right = pd.left + 64;
		pd.bottom = pd.top + 64;
		Draw2D(pirate, ps, pd ,0xffffffff);

		for (std::vector<Fireball*>::iterator it1 = fireballs.begin() ; 
				it1 != fireballs.end( ) ; )
			{
				Fireball* f = (*it1);

				if ((p->x > f->x && p->x < f->x+64
				&& p->y > f->y && p->y < f->y+64) || 
				
				(p->x+64 > f->x && p->x+64 < f->x+64
					&& p->y > f->y && p->y < f->y+64)
					||
				(p->x+64 > f->x && p->x+64 < f->x+64
					&& p->y+64 > f->y && p->y+64 < f->y+64)
					||
				(p->x > f->x && p->x < f->x+64
					&& p->y+64 > f->y && p->y+64 < f->y+64))
				{
					//fireballs.erase(it1);
					p->health = 0;
					score+= 300;
					Explode(p->x, p->y);
				}

				it1++;
			}

		//if (p->health == 0 || p->x > 1200 || p->y > 850)
		//{
		//	pirates.erase(it);
		//}

		it++;
	}

	if (state == 2)
	{
		ClearPirates();
		ClearFireballs();
		ClearExplosions();
	}
}


void DirectXBase::RunFireballs(DWORD delta)
{
	fireballs.erase(std::remove_if(fireballs.begin(), fireballs.end(), FireballRemove()), fireballs.end());

	for (std::vector<Fireball*>::iterator it = fireballs.begin() ; 
		it != fireballs.end( ) ; )
	{
		Fireball* p = (*it);
		p->y -= delta * .3;
		p->rot += delta * .1;

		if (p->rot > D3DX_PI*2)
			p->rot = 0.0f;
		
		RECT ps = {0,0,64,64};
		RECT pd;
		pd.top = (int)p->y;
		pd.left = (int)p->x;
		pd.right = pd.left + 64;
		pd.bottom = pd.top + 64;
		Draw2D(fireball, ps, pd ,p->rot ,0xffffffff);

		//if (p->x < -64)
		//{
		//	fireballs.erase(it);
		//}

		it++;
	}
}

void DirectXBase::RunExplosions(DWORD delta)
{
	explosions.erase(std::remove_if(explosions.begin(), explosions.end(), ExplosionRemove()), explosions.end());

	for (std::vector<Fireball*>::iterator it = explosions.begin() ; 
		it != explosions.end( ) ; )
	{
		Fireball* p = (*it);
		p->rot += delta * .2;


		RECT ps = {0,0,64,64};
		RECT pd;
		pd.top = (int)p->y;
		pd.left = (int)p->x;
		pd.right = pd.left + 64;
		pd.bottom = pd.top + 64;
		Draw2D(fire, ps, pd ,p->rot ,0xffffffff);

		p->x += rand()%20 - 10;
		p->y += rand()%20 - 10;

		pd.top = (int)p->y;
		pd.left = (int)p->x;
		pd.right = pd.left + 64;
		pd.bottom = pd.top + 64;

		Draw2D(fire, ps, pd ,-p->rot ,0xffffffff);

		//if (p->rot > D3DX_PI*20)
		//{
			//explosions.erase(it);
		//}

		it++;
	}
}


void DirectXBase::Shutdown()
{
	ClearPirates();
	ClearFireballs();
	ClearExplosions();
	ShowCursor(TRUE);
	// release devices kthx~
	if( m_pd3dDevice != NULL)     // safe release everything
        m_pd3dDevice->Release();
    if( m_pD3D != NULL)
        m_pD3D->Release();
	if (this->m_sprite)
		this->m_sprite->Release();
	if (menu)
	{
		menu->Release();
		menu = NULL;
	}
	if (water)
	{
		water->Release();
		water = NULL;
	}
	if (ship)
	{
		ship->Release();
		ship = NULL;
	}
	if (gtext)
	{
		gtext->Release();
		gtext = NULL;
	}
	if (fire)
	{
		fire->Release();
		fire= NULL;
	}
	if (fireball)
	{
		fireball->Release();
		fireball= NULL;
	}
}


BOOL DirectXBase::Run()
{
	// check if we have been initialized
	if (!bInit)
		return FALSE;

	MSG msg;

	// Run the message pump
	while (TRUE) 
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
				break;

			//if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
			//{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			//}

		}
		else
		{
			if (state == -1)
			{
				// draw menu

				// Clear
				m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
				// Begin the scene
				m_pd3dDevice->BeginScene();

				char str[32] = "P1RATE BURNINATOR~";

				RECT sr = {100,100,1024,300};

				menu->DrawText(NULL, str, (int)strlen(str), &sr, DT_CENTER|DT_NOCLIP|DT_SINGLELINE, D3DCOLOR_XRGB(0,0,255));

				char intro[] = "You have been recruited to save your country from the Pirate Menace!\n  You have been given a ship equipped with "
					"a burninator (Greek Fire). \nAvoid the pirates or they will board your ship!\nMove with arrow keys, fire a burninating ball with spacebar.\n"
					" Press spacebar to continue...";

				RECT sr1 = {100,200,1024,768};
				gtext->DrawText(NULL, intro, (int)strlen(intro), &sr1, DT_LEFT, D3DCOLOR_XRGB(255,0,0));

				// End the scene
				m_pd3dDevice->EndScene();

				// oMFG PRESENTS 
				m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
			}
			else if (state == 0)
			{
				// draw menu

				// Clear
				m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
				// Begin the scene
				m_pd3dDevice->BeginScene();

				char str[32] = "P1RATE BURNINATOR~";

				RECT sr = {100,100,1024,300};

				menu->DrawText(NULL, str, (int)strlen(str), &sr, DT_CENTER|DT_NOCLIP|DT_SINGLELINE, D3DCOLOR_XRGB(0,0,255));
				
				int selcolor = D3DCOLOR_XRGB(255,255,255);
				int regcolor = D3DCOLOR_XRGB(64,64,64);

				sr.top += 200;
				sr.bottom += 200;

				strcpy(str, "Start Burninating");
				if (sel == 0)
					menu->DrawText(NULL, str, (int)strlen(str), &sr, DT_LEFT|DT_NOCLIP|DT_SINGLELINE, selcolor);
				else
					menu->DrawText(NULL, str, (int)strlen(str), &sr, DT_LEFT|DT_NOCLIP|DT_SINGLELINE, regcolor);
				
				sr.top += 100;
				sr.bottom += 100;

				strcpy(str, "Flee to windows!");
				if (sel == 1)
					menu->DrawText(NULL, str, (int)strlen(str), &sr, DT_LEFT|DT_NOCLIP|DT_SINGLELINE, selcolor);
				else
					menu->DrawText(NULL, str, (int)strlen(str), &sr, DT_LEFT|DT_NOCLIP|DT_SINGLELINE, regcolor);

				// End the scene
				m_pd3dDevice->EndScene();

				// oMFG PRESENTS 
				m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
			}
			else if (state == 1)
			{
				static DWORD end = timeGetTime();
				DWORD begin = timeGetTime();
				DWORD delta = begin - end;

				score+= delta/10.f;

				float svel = 0.4f;
				if (KEYDOWN(VK_LEFT))
					sx -= svel * delta;
				if (KEYDOWN(VK_RIGHT))
					sx += svel * delta;
				if (KEYDOWN(VK_UP))
					sy -= svel * delta;
				if (KEYDOWN(VK_DOWN))
					sy += svel * delta;

				if (firedelay > 0)
					firedelay -= delta;

				if (KEYDOWN(VK_SPACE))
					if (firedelay <= 0)
					{
						FireWeapon();
						// FIRE WEAPON
						firedelay = 750;
					}

				if (sx < 0)
					sx = 0;
				if (sy < 600)
					sy = 600;
				if (sx > (1024-64))
					sx = 1024-64;
				if (sy > (768-64))
					sy = 768-64;

				if (rand()%10 == 0)
					AddPirate();

				//if (rand()%100==0)
				//	Explode(100,100);

				// Clear
				m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
				// Begin the scene
				m_pd3dDevice->BeginScene();

				m_sprite->Begin(D3DXSPRITE_ALPHABLEND);
				// 2d DRAWING


				wshift ++;
				if ((wshift/4)== 768)
					wshift = 0;
				RECT ws;

				ws.top = 0;
				ws.left = 0;
				ws.right = 1024;
				ws.bottom = 768-(wshift/4);

				RECT wd;

				wd.top = (wshift/4);
				wd.bottom = 768;
				wd.left = 0;
				wd.right = 1024;

				Draw2D(water, ws, wd, 0xFFFFFFFF);

				ws.top = 768-(wshift/4);
				ws.left = 0;
				ws.right = 1024;
				ws.bottom = 768;

				wd.top = 0;
				wd.bottom = (wshift/4);
				wd.left = 0;
				wd.right = 1024;

				Draw2D(water, ws, wd, 0xFFFFFFFF);

				RECT ss = {0,0,64,64};
				RECT sd;
				sd.top = (int)sy;
				sd.left = (int)sx;
				sd.right = sd.left + 64;
				sd.bottom = sd.top + 64;
				Draw2D(ship, ss, sd, 0xFFFFFFFF);

				RunPirates(delta);
				RunFireballs(delta);
				RunExplosions(delta);
				m_sprite->End();

				char str[64];

				_snprintf(str, 64, "Burnination: %i", (int)score);
				RECT sr = {10,10,300,300};

				gtext->DrawText(NULL, str, (int)strlen(str), &sr, DT_LEFT|DT_NOCLIP|DT_SINGLELINE, D3DCOLOR_XRGB(255,0,0));

				// End the scene
				m_pd3dDevice->EndScene();

				// oMFG PRESENTS 
				m_pd3dDevice->Present( NULL, NULL, NULL, NULL );

				end = begin;
				//sleep
				Sleep(1);
			}
			else if (state == 2)
			{
				// Clear
				m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
				// Begin the scene
				m_pd3dDevice->BeginScene();

				char str[64]= "OH TEH NOES pirates got you!";
				RECT sr = {0,400,1024,500};

				gtext->DrawText(NULL, str, (int)strlen(str), &sr, DT_CENTER|DT_NOCLIP|DT_SINGLELINE, D3DCOLOR_XRGB(255,0,255));

				_snprintf(str, 64, "Final Burnination Score: %i", (int)score);
				sr.top += 100;
				sr.bottom += 100;

				gtext->DrawText(NULL, str, (int)strlen(str), &sr, DT_CENTER|DT_NOCLIP|DT_SINGLELINE, D3DCOLOR_XRGB(255,0,255));


				// End the scene
				m_pd3dDevice->EndScene();

				// oMFG PRESENTS 
				m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
			}
		}
	}

	return (int) msg.wParam;
}

void DirectXBase::FireWeapon()
{
	Fireball *p = new Fireball();

	p->x = sx;
	p->y = sy-32;
	p->rot = 0.0f;

	this->fireballs.push_back(p);
}

void DirectXBase::Explode (int x, int y)
{
	Fireball *p = new Fireball();

	p->x = x;
	p->y = y;
	p->rot = 0.0f;

	this->explosions.push_back(p);
}

//  PURPOSE: Registers the window class.
ATOM DirectXBase::RegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)DispatchWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, IDI_APPLICATION);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, IDI_APPLICATION);

	return RegisterClassEx(&wcex);
}

BOOL DirectXBase::InitInstance()
{
   hWnd = CreateWindow(szWindowClass, szTitle, WS_POPUP|WS_CAPTION|WS_MINIMIZEBOX|WS_SYSMENU,
	   0, 0, iWidth, iHeight, NULL, NULL, hInst, this);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, SW_SHOW);
   UpdateWindow(hWnd);

   RECT r = {0,0,iWidth,iHeight};

   AdjustWindowRect(&r, WS_POPUP|WS_CAPTION|WS_MINIMIZEBOX , FALSE);
	
   SetWindowPos(hWnd, NULL, 0, 0, r.right, r.bottom, SWP_NOOWNERZORDER);

   // No clue why I need this here, but it works
   SetWindowText(hWnd, szTitle);

   return TRUE;
}

void DirectXBase::InitGame()
{
	firedelay = 0;
	score = 0.0;
	ClearPirates();
	ClearFireballs();
	ClearExplosions();
	sx = 512 - 32;
	sy = 700;
	wshift = 0;
	return;
}

LRESULT CALLBACK DirectXBase::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message) 
	{
	case WM_KEYDOWN:
		if (state == -1)
		{
			if (wParam == VK_SPACE)
			{
				state = 0;
			}
		}
		// OMFG SOMEBUODY PUSHED A BUTTON?~!!?
		/*if (state == 1)
		{
			if (wParam == VK_UP)
				u = TRUE;
			if (wParam == VK_DOWN)
				d = TRUE;
			if (wParam == VK_LEFT)
				l = TRUE;
			if (wParam == VK_RIGHT)
				r = TRUE;
		}*/

		if (state == 0)
		{
			if (wParam == VK_UP)
				sel--;
			if (wParam == VK_DOWN)
				sel++;

			if (sel > 1)
				sel = 0;
			if (sel < 0)
				sel = 1;

			if (wParam == VK_RETURN)
			{
				if (sel == 0)
				{
					InitGame();
					state = 1; // START GAME
				}
				else
					PostQuitMessage(0);
			}
		}

		// quit
		if (wParam == VK_ESCAPE)
		{
			if (state == 0 || state == -1)
				PostQuitMessage(0);
			else 
				// reset game?
				state = 0;
		}
	/*case WM_KEYUP: 
		// OMFG SOMEBUODY PUSHED A BUTTON?~!!?
		if (state == 1)
		{
			if (wParam == VK_UP)
				u = FALSE;
			if (wParam == VK_DOWN)
				d = FALSE;
			if (wParam == VK_LEFT)
				l = FALSE;
			if (wParam == VK_RIGHT)
				r = FALSE;
		}
		break;*/
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}


// 2d DRAWING FUNCTIONS
void DirectXBase::Draw2D(LPDIRECT3DTEXTURE9 tex, RECT src, RECT dest, D3DCOLOR mod)
{
	D3DXMATRIX scale, translation, transform;
	D3DXMatrixIdentity(&scale);
	D3DXMatrixIdentity(&translation);

	D3DXMatrixScaling(&scale, ((float)(dest.right-dest.left))/(src.right-src.left), 
								  ((float)(dest.top-dest.bottom))/(src.top-src.bottom),
								  1.0f);

	D3DXMatrixTranslation(&translation, (float)dest.left, (float)dest.top, 0.0f);

	D3DXMatrixMultiply(&transform, &scale, &translation);

	m_sprite->SetTransform(&transform);
	m_sprite->Draw(tex, &src, NULL, NULL, mod);
}

void DirectXBase::Draw2D(LPDIRECT3DTEXTURE9 tex, RECT src, RECT dest, float rot, D3DCOLOR mod)
{
	D3DXMATRIX out;
	D3DXVECTOR2 scalecenter;
	//float scalingrotation = 0.0f;
	D3DXVECTOR2 scaling;
	D3DXVECTOR2 rotationcenter;
	D3DXVECTOR2 translation;

	scalecenter.x = rotationcenter.x = (src.right - src.left)/2.0f;
	scalecenter.y = rotationcenter.y = (src.bottom - src.top)/2.0f;

	scaling.x = ((float)(dest.right - dest.left))/(src.right - src.left);
	scaling.y = ((float)(dest.bottom - dest.top))/(src.bottom - src.top);

	translation.x = (float)dest.left /*- src.left*/;
	translation.y = (float)dest.top /*- src.top*/;

	D3DXMatrixTransformation2D(&out, NULL, /*&scalingrotation*/ 0.0f, &scaling, &rotationcenter, /*&*/ rot, &translation);

	m_sprite->SetTransform(&out);
	m_sprite->Draw(tex, &src, NULL, NULL, mod);
}
