Endurion's entry for the Gamedev 3h compo #2:
=============================================

Story (what do you expect?):
----------------------------
Sam the firefighter has a tough life. He needs to rescue all the victim from the burning
skyscraper and he needs to do it fast! Only armed by his wits and a fire hose he moves on
the buildings front. He can extinguish the flames to be able to pass through.

Controls:
---------
Use the cursor keys to move Sam. Move over a victim (the upper half of Sam!) to rescue them. Use space
to shoot a blast of water. Beware, you cannot move when you do that! Keep Shift pressed to turn left or right.
This is of importance, since Sam can blast water to his left or right.

Rescue all the victims before the time is up to get to the next level!

On any event (Well Done,Get Ready, Game Over) press space to continue.
Press Escape to quit the game at once.


The game has been written using DX9 (the supplied DXBase) and VS2003.

Have fun!


About the author:
Georg "Endurion" Rottensteiner
endurion@gmx.de
Visit my homepage at http://www.georg-rottensteiner.de