#pragma once
#include "unit.h"

class CFire : public CUnit
{

  public:

    float         m_fAnimDelay;


    CFire(void);
    virtual ~CFire(void);

    virtual void  Display();
    virtual void  Update( const float fElapsedTime );

};
