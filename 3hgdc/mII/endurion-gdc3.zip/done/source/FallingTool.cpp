#include ".\fallingtool.h"
#include ".\DXBase.h"



CFallingTool::CFallingTool()
{
  m_iType = rand() % 1;
  m_iTurn = 0;
  m_fAnimDelay = 0.0f;
  m_bCanCollide = true;

  m_iTX = 0;
  m_iTY = 0;
  m_iTW = 20;
  m_iTH = 20;

  switch ( m_iType )
  {
    case 0:
      m_iTX = 138;
      m_iTY = 86;
      m_iTW = 28;
      m_iTH = 23;
      break;
  }

}

CFallingTool::~CFallingTool(void)
{
}



void CFallingTool::Display()
{

  theApp.RenderQuad( (int)m_fX + 20 - m_iTW / 2, (int)( m_fY - theApp.m_fLevelOffset ), m_iTW, m_iTH,
                    m_iTX, m_iTY,
                    m_iTW, m_iTH );

}



void CFallingTool::Update( const float fElapsedTime )
{

  CUnit::Update( fElapsedTime );

  m_fY += 100.0f * fElapsedTime;

  if ( m_fY >= theApp.m_iLevelHeight * 40.0f + 100.0f )
  {
    m_bRemoveMe = true;
  }

  m_fAnimDelay += fElapsedTime;
  if ( m_fAnimDelay >= 0.25f )
  {
    m_iTurn = ( m_iTurn + 1 ) % 4;
    m_fAnimDelay -= 0.25f;
  }

}



RECT CFallingTool::CollisionRect()
{

  RECT    rc;

  SetRect( &rc, (int)m_fX, (int)m_fY, (int)m_fX + m_iTW, (int)m_fY + m_iTH );

  return rc;

}