#pragma once
#include "unit.h"

class CFallingTool : public CUnit
{

  public:

    int               m_iType;
    int               m_iTurn;

    int               m_iTX;
    int               m_iTY;
    int               m_iTW;
    int               m_iTH;

    float             m_fAnimDelay;


    CFallingTool();
    virtual ~CFallingTool();

    virtual void  Display();
    virtual void  Update( const float fElapsedTime );

    virtual RECT  CollisionRect();

};
