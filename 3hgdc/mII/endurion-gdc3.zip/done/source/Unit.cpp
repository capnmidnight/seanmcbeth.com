#include ".\unit.h"

CUnit::CUnit() :
  m_bRemoveMe( false ),
  m_bMoving( false ),
  m_fX( 0.0f ),
  m_fY( 0.0f ),
  m_fXTarget( 0.0f ),
  m_fYTarget( 0.0f ),
  m_fSpeed( 40.0f ),
  m_iTileX( 0 ),
  m_iTileY( 0 ),
  m_bPlayerUnit( false ),
  m_bCanCollide( false )
{
}

CUnit::~CUnit(void)
{
}



void CUnit::Display()
{
}



void CUnit::Update( const float fElapsedTime )
{

  if ( m_bMoving )
  {
    if ( m_fXTarget < m_fX )
    {
      m_fX -= m_fSpeed * fElapsedTime;
      if ( m_fX < m_fXTarget )
      {
        m_fX = m_fXTarget;
      }
    }
    if ( m_fXTarget > m_fX )
    {
      m_fX += m_fSpeed * fElapsedTime;
      if ( m_fX > m_fXTarget )
      {
        m_fX = m_fXTarget;
      }
    }
    if ( m_fYTarget < m_fY )
    {
      m_fY -= m_fSpeed * fElapsedTime;
      if ( m_fY < m_fYTarget )
      {
        m_fY = m_fYTarget;
      }
    }
    if ( m_fYTarget > m_fY )
    {
      m_fY += m_fSpeed * fElapsedTime;
      if ( m_fY > m_fYTarget )
      {
        m_fY = m_fYTarget;
      }
    }
    if ( ( m_fX == m_fXTarget )
    &&   ( m_fY == m_fYTarget ) )
    {
      m_bMoving = false;
    }
  }

}



void CUnit::ToTarget( float fTX, float fTY )
{

  m_fXTarget = fTX;
  m_fYTarget = fTY;

  m_bMoving = true;

}



RECT CUnit::CollisionRect()
{

  RECT    rc;

  SetRect( &rc, 0, 0, 0, 0 );

  return rc;

}