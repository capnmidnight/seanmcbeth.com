#pragma once

#include <windows.h>

class CUnit
{

  public:


    float         m_fX;
    float         m_fY;

    int           m_iTileX;
    int           m_iTileY;

    float         m_fSpeed;

    float         m_fXTarget;
    float         m_fYTarget;

    bool          m_bRemoveMe,
                  m_bMoving,
                  m_bPlayerUnit,
                  m_bCanCollide;


    CUnit();
    virtual ~CUnit();


    virtual void  Display();
    virtual void  Update( const float fElapsedTime );

    void          ToTarget( float fTX, float fTY );

    virtual RECT  CollisionRect();

};
