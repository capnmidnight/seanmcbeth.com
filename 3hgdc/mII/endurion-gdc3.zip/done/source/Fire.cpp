#include ".\fire.h"
#include ".\DXBase.h"



CFire::CFire() :
  m_fAnimDelay( 0.0f )
{
}

CFire::~CFire(void)
{
}



void CFire::Display()
{

  // Hightech animation system
  if ( m_fAnimDelay < 0.125f )
  {
    theApp.RenderQuad( (int)m_fX - 3 - 3, (int)( m_fY - theApp.m_fLevelOffset ) - 8, 46, 48,
                      1, 65,
                      46, 48 );
  }
  else
  {
    theApp.RenderQuad( (int)m_fX - 3 + 3, (int)( m_fY - theApp.m_fLevelOffset ) - 8, 46, 48,
                      45, 65,
                      -46, 48 );
  }

}



void CFire::Update( const float fElapsedTime )
{

  m_fAnimDelay += fElapsedTime;
  if ( m_fAnimDelay >= 0.25f )
  {
    m_fAnimDelay -= 0.25f;
    m_fAnimDelay += ( rand() % 100 ) * 0.0005f;
  }
  CUnit::Update( fElapsedTime );

}