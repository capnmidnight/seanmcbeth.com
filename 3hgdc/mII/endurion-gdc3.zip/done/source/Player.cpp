#include ".\player.h"
#include ".\DXBase.h"



CPlayer::CPlayer()
{
  m_fSpeed = 120.0f;
  m_bDied = false;
  m_fShootWater = 0.0f;
  m_bLookLeft = true;
  m_bPlayerUnit = true;
  m_bCanCollide = true;
}



CPlayer::~CPlayer()
{
}



void CPlayer::Display()
{

  if ( m_bDied )
  {
    theApp.RenderQuad( (int)m_fX, (int)( m_fY - theApp.m_fLevelOffset ), 40, 64,
                      1, 191 + 63,
                      40, -64 );
  }
  else
  {
    if ( m_bLookLeft )
    {
      theApp.RenderQuad( (int)m_fX, (int)( m_fY - theApp.m_fLevelOffset ), 40, 64,
                        1, 191,
                        40, 64 );

      // hose
      theApp.RenderQuad( (int)m_fX + 32, (int)( m_fY - theApp.m_fLevelOffset ) + 57, 5, 480,
                         32, 251,
                         5, 2 );
    }
    else
    {
      theApp.RenderQuad( (int)m_fX, (int)( m_fY - theApp.m_fLevelOffset ), 40, 64,
                        40, 191,
                        -40, 64 );

      // hose
      theApp.RenderQuad( (int)m_fX + 5, (int)( m_fY - theApp.m_fLevelOffset ) + 57, 5, 480,
                         32, 251,
                         5, 2 );
    }
    if ( m_fShootWater )
    {
      if ( m_bLookLeft )
      {
        theApp.RenderQuad( (int)m_fX - 20, (int)( m_fY - theApp.m_fLevelOffset ) - 30, 28, 26,
                          96, 80,
                          28, 26 );
      }
      else
      {
        theApp.RenderQuad( (int)m_fX + 30, (int)( m_fY - theApp.m_fLevelOffset ) - 30, 28, 26,
                          96 + 28, 80,
                          -28, 26 );
      }
    }
  }

}


void CPlayer::Update( const float fElapsedTime )
{

  CUnit::Update( fElapsedTime );

  if ( m_bDied )
  {
    m_fY += 200.0f * fElapsedTime;
    if ( m_fY > theApp.m_iLevelHeight * 40.0f + 100.0f )
    {
      theApp.m_iLives--;
      if ( theApp.m_iLives == 0 )
      {
        theApp.m_bGameOver = true;
        return;
      }
      else
      {
        // reset player
        m_bMoving = false;
        m_fX = 320.0f;
        m_fY = theApp.m_iLevelHeight * 40.0f - 80.0f;
        m_iTileX = 8;
        m_iTileY = theApp.m_iLevelHeight - 2;
        m_bDied = false;
      }
    }
  }
  else if ( !m_bMoving )
  {
    if ( m_fShootWater > 0.0f )
    {
      m_fShootWater -= fElapsedTime;
      if ( m_fShootWater < 0.0f )
      {
        m_fShootWater = 0.0f;

        // did i extinguish a fire?
        if ( m_bLookLeft )
        {
          if ( theApp.GetField( m_iTileX - 1, m_iTileY - 1 ) == 2 )
          {
            theApp.RemoveUnitAt( m_iTileX - 1, m_iTileY - 1 );
          }
        }
        else
        {
          if ( theApp.GetField( m_iTileX + 1, m_iTileY - 1 ) == 2 )
          {
            theApp.RemoveUnitAt( m_iTileX + 1, m_iTileY - 1 );
          }
        }
      }
    }
    if ( theApp.GetField( m_iTileX, m_iTileY ) == 3 )
    {
      // rescued victim
      theApp.RemoveUnitAt( m_iTileX, m_iTileY );
      theApp.m_iVictimsToSave--;
    }
    if ( ( theApp.GetField( m_iTileX, m_iTileY ) == 2 )
    ||   ( theApp.GetField( m_iTileX, m_iTileY + 1 ) == 2 ) )
    {
      m_bDied = true;
      return;
    }

	  if ( ( theApp.m_bKeyPressed[VK_SPACE] )
    &&   ( theApp.m_bKeyReleased[VK_SPACE] )
    &&   ( m_fShootWater == 0.0f ) )
    {
      theApp.m_bKeyReleased[VK_SPACE] = false;
      m_fShootWater = 1.0f;
    }

    if ( m_fShootWater == 0.0f )
    {
      if ( ( theApp.m_bKeyPressed[VK_LEFT] )
      &&   ( theApp.m_bKeyPressed[VK_SHIFT] ) )
      {
        m_bLookLeft = true;
      }
      else if ( ( theApp.m_bKeyPressed[VK_RIGHT] )
      &&        ( theApp.m_bKeyPressed[VK_SHIFT] ) )
      {
        m_bLookLeft = false;
      }
      else if ( ( theApp.m_bKeyPressed[VK_LEFT] )
      &&        ( m_iTileX > 0 ) )
      {
        ToTarget( m_iTileX * 40.0f - 40.0f, m_fY );
        m_iTileX--;
        m_bLookLeft = true;
      }
      else if ( ( theApp.m_bKeyPressed[VK_RIGHT] )
      &&        ( m_iTileX + 1 < 16 ) )
      {
        ToTarget( m_iTileX * 40.0f + 40.0f, m_fY );
        m_iTileX++;
        m_bLookLeft = false;
      }
      else if ( ( theApp.m_bKeyPressed[VK_DOWN] )
      &&        ( m_iTileY + 2 < theApp.m_iLevelHeight ) )
      {
        ToTarget( m_fX, m_iTileY * 40.0f + 40.0f );
        ++m_iTileY;
      }
      else if ( ( theApp.m_bKeyPressed[VK_UP] )
      &&        ( m_iTileY > 0 ) )
      {
        ToTarget( m_fX, m_iTileY * 40.0f - 40.0f );
        --m_iTileY;
      }
    }
  }

  if ( m_fY - theApp.m_fLevelOffset < 140.0f )
  {
    theApp.m_fLevelOffset = m_fY - 140.0f;
    if ( theApp.m_fLevelOffset < 0.0f )
    {
      theApp.m_fLevelOffset = 0.0f;
    }
  }
  if ( m_fY - theApp.m_fLevelOffset > 360.0f )
  {
    theApp.m_fLevelOffset = m_fY - 360.0f;
    if ( theApp.m_fLevelOffset > ( theApp.m_iLevelHeight - 12 ) * 40.0f )
    {
      theApp.m_fLevelOffset = ( theApp.m_iLevelHeight - 12 ) * 40.0f;
    }
  }

}



RECT CPlayer::CollisionRect()
{

  RECT    rc;

  SetRect( &rc, (int)m_fX, (int)m_fY, (int)m_fX + 40, (int)m_fY + 64 );

  return rc;

}