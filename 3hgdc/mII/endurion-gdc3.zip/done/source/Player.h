#pragma once
#include "unit.h"

class CPlayer : public CUnit
{

  public:

    float         m_fShootWater;

    bool          m_bDied,
                  m_bLookLeft;


    CPlayer(void);
    virtual ~CPlayer(void);


    virtual void  Display();
    virtual void  Update( const float fElapsedTime );

    virtual RECT  CollisionRect();

};
