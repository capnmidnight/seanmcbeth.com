#pragma once
#include "unit.h"

class CVictim :
  public CUnit
{
public:
  CVictim(void);
  virtual ~CVictim(void);

    virtual void  Display();
    virtual void  Update( const float fElapsedTime );

};
