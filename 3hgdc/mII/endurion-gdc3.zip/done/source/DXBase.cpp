#pragma comment( lib, "d3d9.lib" )
#pragma comment( lib, "d3dx9.lib" )

#include <d3d9.h>
#include <d3dx9.h>


#include "DXbase.h"
#include "Player.h"
#include "Fire.h"
#include "Victim.h"
#include "FallingTool.h"


DirectXBase    theApp( GetModuleHandle( NULL ) );



DirectXBase::DirectXBase(HINSTANCE hInstance)
{

  m_bGameOver = false;
  m_bGetReady = true;
  m_bWellDone = false;

  m_pLevelData = NULL;

	bInit = FALSE;

	// Set pointers to NULL in case something goes wrong
	m_pd3dDevice = NULL;
	m_pD3D = NULL;

	hWnd = NULL;
	hInst = hInstance;

	strcpy(szWindowClass,"dxsample");
	strcpy(szTitle,"3Hour Compo");
}

DirectXBase::~DirectXBase(void)
{
}

BOOL DirectXBase::Init(BOOL windowed, int BPP, int Width, int Height)
{
	// Return Value: TRUE if succeeded, else FALSE

	bWindowed = windowed;
	iBpp = BPP;
	iWidth = Width;
	iHeight = Height;

	// set up the window
	RegisterClass(hInst);

	// Perform application initialization:
	if (!InitInstance ()) 
	{
		bInit = FALSE;
		return FALSE;
	}

  for ( int i = 0; i < 256; ++i )
  {
    m_bKeyPressed[i] = false;
    m_bKeyReleased[i] = true;
  }

	// start up Direct3d
	if( NULL == ( m_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
		return FALSE;

	// fill up the present parameters
	D3DPRESENT_PARAMETERS d3dpp; 
	
	ZeroMemory( &d3dpp, sizeof(d3dpp) );
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.Windowed = bWindowed;
	d3dpp.hDeviceWindow = hWnd;

	// stencil depth and things
	// Uncomment for depth stencil
	d3dpp.EnableAutoDepthStencil = FALSE;
	//d3dpp.EnableAutoDepthStencil = TRUE;
    //d3dpp.AutoDepthStencilFormat = D3DFMT_D24X8;


	// Dont wait for the vertical retrace
	d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	// check if its running windowed or fullscreen
	if (bWindowed)
	{
		// we dont need to do much here
		d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
		d3dpp.Windowed = TRUE;
	}
	else 
	{
		// initial setup
		d3dpp.Windowed = FALSE;		

		// get the color depth
		if (iBpp == 32 || iBpp == 24)
			d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
		else if (iBpp == 16)
			d3dpp.BackBufferFormat = D3DFMT_R5G6B5;
		else return FALSE;

		// set the requested size
		d3dpp.BackBufferHeight = iHeight;
		d3dpp.BackBufferWidth  = iWidth;

		// now we need to check if the display mode is supported
		D3DDISPLAYMODE d3ddm;
		BOOL bSupported=FALSE;

		// loop through the available adapter modes
		UINT count=m_pD3D->GetAdapterModeCount(D3DADAPTER_DEFAULT, d3dpp.BackBufferFormat);

		for(UINT i=0; i<count; i++)
		{
			if( FAILED(m_pD3D->EnumAdapterModes(D3DADAPTER_DEFAULT,
											d3dpp.BackBufferFormat,
											i, &d3ddm)))
				return FALSE;

			// check and see if it matches our settings
			if (d3ddm.Height == d3dpp.BackBufferHeight && 
				d3ddm.Width  == d3dpp.BackBufferWidth)
			{
				bSupported = TRUE; // its a match, break out of the loop
				break;
			}
		}

		// Check for hardware support
		if(FAILED( m_pD3D->CheckDeviceType(D3DADAPTER_DEFAULT, 
                                        D3DDEVTYPE_HAL, 
                                        d3dpp.BackBufferFormat, 
                                        d3dpp.BackBufferFormat, 
										d3dpp.Windowed)))

			return FALSE;

		if(!bSupported)    // we didnt find the right mode, call fails
			return FALSE;


	}



	// Create the device
	if( FAILED( m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
								D3DCREATE_SOFTWARE_VERTEXPROCESSING,
								&d3dpp, &m_pd3dDevice ) ) )
		return FALSE;

	bInit = TRUE;

  LoadTexture( "Tiles", "tiles.bmp", 0xffff00ff );
  LoadTexture( "Texts", "texts.bmp", 0xff000000 );

  m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
  m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

  m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE );
  m_pd3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );
  m_pd3dDevice->SetRenderState( D3DRS_ALPHAREF, 8 );

  m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_MODULATE );
  m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
  m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

  m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_MODULATE );
  m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
  m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

  m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
  m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
  m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR );


  m_iLevel = 1;
  m_iLives = 3;

  PrepareLevel();

	return bInit;
}



void DirectXBase::LoadTexture( const std::string& strDesc, const char* szFileName, DWORD dwColorKey )
{

  IDirect3DTexture9*  pTex = NULL;

  if ( dwColorKey == 0 )
  {
    if ( FAILED( D3DXCreateTextureFromFile( m_pd3dDevice, szFileName, &pTex ) ) )
    {
      return;
    }
  }
  else
  {
    if ( FAILED( D3DXCreateTextureFromFileEx( m_pd3dDevice,   
                                              szFileName,
                                              0,
                                              0,
                                              1,
                                              0,
                                              D3DFMT_UNKNOWN,
                                              D3DPOOL_MANAGED,
                                              D3DX_FILTER_NONE,
                                              D3DX_FILTER_NONE,
                                              dwColorKey,
                                              NULL,
                                              NULL,
                                              &pTex ) ) )
    {
      return;
    }
  }
  m_mapTextures[strDesc] = pTex;

}



void DirectXBase::Shutdown()
{

  ClearUnits();
  if ( m_pLevelData )
  {
    delete[] m_pLevelData;
    m_pLevelData = NULL;
  }

  tMapTextures::iterator    it( m_mapTextures.begin() );
  while ( it != m_mapTextures.end() )
  {
    IDirect3DTexture9*  pTexture = it->second;

    pTexture->Release();

    ++it;
  }
  m_mapTextures.clear();

	if ( m_pd3dDevice != NULL )
  {
    m_pd3dDevice->Release();
    m_pd3dDevice = NULL;
  }
  if ( m_pD3D != NULL )
  {
    m_pD3D->Release();
    m_pD3D = NULL;
  }

}



BOOL DirectXBase::Run()
{
	if ( !bInit )
  {
		return FALSE;
  }

	MSG msg;

	while ( true )
	{
		while ( PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE ) )
		{
      GetMessage( &msg, NULL, 0, 0 );
			if ( msg.message == WM_QUIT )
      {
				break;
      }

			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		if ( msg.message == WM_QUIT )
    {
			break;
    }

    if ( m_pd3dDevice )
    {
		  m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,255), 1.0f, 0 );

		  if ( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
      {
        DisplayFrame( m_pd3dDevice );

		    m_pd3dDevice->EndScene();
      }
		  m_pd3dDevice->Present( NULL, NULL, NULL, NULL );	
    }

    {
      static DWORD    dwLastTicks = GetTickCount();
      
      DWORD dwCurTicks = GetTickCount();

      float fElapsedTime = ( dwCurTicks - dwLastTicks ) * 0.001f;

      dwLastTicks = dwCurTicks;

      UpdateFrame( fElapsedTime );
    }
	}

	return 0;
}



ATOM DirectXBase::RegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)DispatchWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, IDI_APPLICATION);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, IDI_APPLICATION);

	return RegisterClassEx(&wcex);
}

BOOL DirectXBase::InitInstance()
{

  // TODO - da klappt was mit der Gr�sse nicht!

  RECT    rcWindow;

  SetRect( &rcWindow, 0, 0, 640, 480 );
  AdjustWindowRect( &rcWindow, WS_POPUP|WS_CAPTION|WS_MINIMIZEBOX|WS_SYSMENU, FALSE );

  OffsetRect( &rcWindow, rcWindow.left, rcWindow.top );
    OffsetRect( &rcWindow,
                ( GetSystemMetrics( SM_CXSCREEN ) - ( rcWindow.right - rcWindow.left ) ) / 2,
                ( GetSystemMetrics( SM_CYSCREEN ) - ( rcWindow.bottom - rcWindow.top ) ) / 2 );

   hWnd = CreateWindow(szWindowClass, szTitle, WS_POPUP|WS_CAPTION|WS_MINIMIZEBOX|WS_SYSMENU,
     rcWindow.left, rcWindow.top, rcWindow.right - rcWindow.left, rcWindow.bottom - rcWindow.top, NULL, NULL, hInst, this);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, SW_SHOW);
   UpdateWindow(hWnd);

   /*
   RECT r = {0,0,iWidth,iHeight};

   AdjustWindowRect(&r, WS_POPUP|WS_CAPTION|WS_MINIMIZEBOX , FALSE);
	
   SetWindowPos(hWnd, NULL, 0, 0, r.right, r.bottom, SWP_NOOWNERZORDER);
   */

   // No clue why I need this here, but it works
   SetWindowText(hWnd, szTitle);

   return TRUE;
}

LRESULT CALLBACK DirectXBase::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	

	switch (message) 
	{
	  case WM_KEYDOWN:
      m_bKeyPressed[wParam] = true;
      break;
	  case WM_KEYUP:
      m_bKeyPressed[wParam] = false;
      m_bKeyReleased[wParam] = true;
      break;
	  case WM_PAINT:
      {
        /*
        PAINTSTRUCT ps;

		    HDC hdc = BeginPaint(hWnd, &ps);
		    EndPaint(hWnd, &ps);
        */

        if ( m_pd3dDevice )
        {
		      m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,255), 1.0f, 0 );

		      if ( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
          {
            DisplayFrame( m_pd3dDevice );

		        m_pd3dDevice->EndScene();
          }
		      m_pd3dDevice->Present( NULL, NULL, NULL, NULL );	
        }
        ValidateRect( hWnd, NULL );


        return TRUE;
      }
	  case WM_DESTROY:
      Shutdown();
		  PostQuitMessage( 0 );
		  break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}




void DirectXBase::RenderQuad( int iX, int iY, int iWidth, int iHeight,
                              int iTX, int iTY, int iTW, int iTH,
                              DWORD dwColor )
{

  struct CUSTOMVERTEX
  {
      D3DXVECTOR3   position; // The position
      float         fRHW;
      D3DCOLOR      color;    // The color
      float         fTU,
                    fTV;
  };

  CUSTOMVERTEX          vertData[4];


  float   fTU1 = (float)iTX / 256.0f;
  float   fTV1 = (float)iTY / 256.0f;
  float   fTU2 = (float)( iTX + iTW ) / 256.0f;
  float   fTV2 = (float)( iTY + iTH ) / 256.0f;


  float   fDelta = -0.5f;

  float   fRHW = 1.0f;

  D3DXVECTOR3   ptPos( (float)iX, (float)iY, 0.0f );
  D3DXVECTOR3   ptSize( (float)iWidth, (float)iHeight, 0.0f );

  m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1 );

  vertData[0].position.x  = ptPos.x + fDelta;
  vertData[0].position.y  = ptPos.y + fDelta;
  vertData[0].position.z  = (float)ptPos.z;
  vertData[0].fRHW        = fRHW;
  vertData[0].color       = dwColor;
  vertData[0].fTU         = fTU1;
  vertData[0].fTV         = fTV1;

  vertData[1].position.x  = ptPos.x + ptSize.x + fDelta;
  vertData[1].position.y  = ptPos.y + fDelta;
  vertData[1].position.z  = (float)ptPos.z;
  vertData[1].fRHW        = fRHW;
  vertData[1].color       = dwColor;
  vertData[1].fTU         = fTU2;
  vertData[1].fTV         = fTV1;

  vertData[2].position.x  = ptPos.x + fDelta;
  vertData[2].position.y  = ptPos.y + ptSize.y + fDelta;
  vertData[2].position.z  = (float)ptPos.z;
  vertData[2].fRHW        = fRHW;
  vertData[2].color       = dwColor;
  vertData[2].fTU         = fTU1;
  vertData[2].fTV         = fTV2;

  vertData[3].position.x  = ptPos.x + ptSize.x + fDelta;
  vertData[3].position.y  = ptPos.y + ptSize.y + fDelta;
  vertData[3].position.z  = (float)ptPos.z;
  vertData[3].fRHW        = fRHW;
  vertData[3].color       = dwColor;
  vertData[3].fTU         = fTU2;
  vertData[3].fTV         = fTV2;

  m_pd3dDevice->DrawPrimitiveUP(
                  D3DPT_TRIANGLESTRIP,
                  2,
                  &vertData,
                  sizeof( vertData[0] ) );

}




void DirectXBase::DisplayFrame( IDirect3DDevice9* pDevice )
{

  pDevice->SetTexture( 0, m_mapTextures["Tiles"] );

  pDevice->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE );

  for ( int i = 0; i < 16; ++i )
  {
    for ( int j = -1; j < 13; ++j )
    {
      int   iTile = GetField( i, (int)( m_fLevelOffset / 40.0f ) + j );

      switch ( iTile )
      {
        case 0:
        case 2:
        case 3:
          // Windowed Tile
          RenderQuad( i * 40, j * 40 - ( (int)m_fLevelOffset ) % 40, 40, 40,
                      1, 1, 62, 62 );
          break;
        case 1:
          // Floor Tile
          RenderQuad( i * 40, j * 40 - ( (int)m_fLevelOffset ) % 40, 40, 40,
                      65, 1, 62, 62 );
          break;
      }
    }
  }

  pDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );

  tListUnits::iterator    it( m_listUnits.begin() );
  while ( it != m_listUnits.end() )
  {
    CUnit*    pUnit = *it;

    pUnit->Display();

    ++it;
  }

  RenderQuad( 5, 5, 81, 15, 2, 140, 81, 15, 0xff00ff00 );
  RenderQuad( 175, 5, 51, 15, 85, 140, 51, 15, 0xffffff00 );
  RenderQuad( 390, 5, 57, 15, 137, 140, 57, 15, 0xff00ffff );
  RenderQuad( 545, 5, 60, 15, 194, 140, 60, 15, 0xffa0a0a0 );


  DisplayNumber( 88 + 1, 5, m_iVictimsToSave, 3, 0xff000000 );
  DisplayNumber( 88 - 1, 5, m_iVictimsToSave, 3, 0xff000000 );
  DisplayNumber( 88, 5 + 1, m_iVictimsToSave, 3, 0xff000000 );
  DisplayNumber( 88, 5 - 1, m_iVictimsToSave, 3, 0xff000000 );
  DisplayNumber( 88, 5, m_iVictimsToSave, 3, 0xff00ff00 );

  DisplayNumber( 230 + 1, 5, (int)m_fTimeLeft, 4, 0xff000000 );
  DisplayNumber( 230 - 1, 5, (int)m_fTimeLeft, 4, 0xff000000 );
  DisplayNumber( 230, 5 + 1, (int)m_fTimeLeft, 4, 0xff000000 );
  DisplayNumber( 230, 5 - 1, (int)m_fTimeLeft, 4, 0xff000000 );
  DisplayNumber( 230, 5, (int)m_fTimeLeft, 4, 0xffffff00 );

  DisplayNumber( 450 + 1, 5, m_iLives, 1, 0xff000000 );
  DisplayNumber( 450 - 1, 5, m_iLives, 1, 0xff000000 );
  DisplayNumber( 450, 5 + 1, m_iLives, 1, 0xff000000 );
  DisplayNumber( 450, 5 - 1, m_iLives, 1, 0xff000000 );
  DisplayNumber( 450, 5, m_iLives, 1, 0xff00ffff );

  DisplayNumber( 610 + 1, 5, m_iLevel, 2, 0xff000000 );
  DisplayNumber( 610 - 1, 5, m_iLevel, 2, 0xff000000 );
  DisplayNumber( 610, 5 + 1, m_iLevel, 2, 0xff000000 );
  DisplayNumber( 610, 5 - 1, m_iLevel, 2, 0xff000000 );
  DisplayNumber( 610, 5, m_iLevel, 2, 0xffa0a0a0 );

  if ( m_bGameOver )
  {
    pDevice->SetTexture( 0, m_mapTextures["Texts"] );

    RenderQuad( ( 640 - 256 ) / 2, ( 480 - 36 ) / 2,
                256, 36,
                0, 80, 256, 36 );
  }
  else if ( m_bGetReady )
  {
    pDevice->SetTexture( 0, m_mapTextures["Texts"] );

    RenderQuad( ( 640 - 256 ) / 2, ( 480 - 35 ) / 2,
                256, 35,
                0, 44, 256, 35 );
  }
  else if ( m_bWellDone )
  {
    pDevice->SetTexture( 0, m_mapTextures["Texts"] );

    RenderQuad( ( 640 - 256 ) / 2, ( 480 - 36 ) / 2,
                256, 36,
                0, 5, 256, 36 );
  }

}



void DirectXBase::UpdateFrame( const float fElapsedTime )
{

  m_fTimeLeft -= fElapsedTime;
  if ( m_fTimeLeft < 0.0f )
  {
    // TODO - Gameover
    m_fTimeLeft = 0.0f;
    m_bGameOver = true;
  }

  if ( ( m_iVictimsToSave == 0 )
  &&   ( !m_bWellDone ) )
  {
    m_bWellDone = true;
  }

  if ( m_bGameOver )
  {
	  if ( ( m_bKeyPressed[VK_SPACE] )
    &&   ( m_bKeyReleased[VK_SPACE] ) )
    {
      m_bKeyReleased[VK_SPACE] = false;
      m_bGameOver = false;

      // Restart game
      m_iLevel = 1;
      m_iLives = 3;
      PrepareLevel();
      m_bGetReady = true;
    }
  }
  else if ( m_bGetReady )
  {
	  if ( ( m_bKeyPressed[VK_SPACE] )
    &&   ( m_bKeyReleased[VK_SPACE] ) )
    {
      m_bKeyReleased[VK_SPACE] = false;
      m_bGetReady = false;

    }
  }
  else if ( m_bWellDone )
  {
	  if ( ( m_bKeyPressed[VK_SPACE] )
    &&   ( m_bKeyReleased[VK_SPACE] ) )
    {
      m_bKeyReleased[VK_SPACE] = false;
      m_bWellDone = false;

      m_iLevel++;

      m_bGetReady = true;
      PrepareLevel();
    }
  }
  else
  {
    tListUnits::iterator    it( m_listUnits.begin() );
    while ( it != m_listUnits.end() )
    {
      CUnit*    pUnit = *it;

      if ( pUnit->m_bRemoveMe )
      {
        it = m_listUnits.erase( it );
        delete pUnit;
        continue;
      }

      if ( pUnit->m_bCanCollide )
      {
        tListUnits::iterator    itOther( m_listUnits.begin() );
        while ( itOther != m_listUnits.end() )
        {
          CUnit*    pOtherUnit = *itOther;

          if ( ( pOtherUnit->m_bCanCollide )
          &&   ( pOtherUnit != pUnit )
          &&   ( IntersectRect( &RECT(), &pUnit->CollisionRect(), &pOtherUnit->CollisionRect() ) ) )
          {
            if ( pUnit->m_bPlayerUnit )
            {
              ( (CPlayer*)pUnit )->m_bDied = true;
            }
          }

          ++itOther;
        }
      }

      pUnit->Update( fElapsedTime );

      ++it;
    }

	  if ( ( m_bKeyPressed[VK_ESCAPE] )
    &&   ( m_bKeyReleased[VK_ESCAPE] ) )
    {
      m_bKeyReleased[VK_ESCAPE] = false;
		  PostQuitMessage( 0 );
    }

    if ( ( rand() % 1000 ) >= 995 )
    {
      CFallingTool*   pTool = new CFallingTool();
      pTool->m_fX = ( rand() % 16 ) * 40.0f;
      pTool->m_fY = -80.0f;
      m_listUnits.push_back( pTool );
    }
  }

}



void DirectXBase::PrepareLevel()
{

  ClearUnits();

  if ( m_pLevelData )
  {
    delete[] m_pLevelData;
    m_pLevelData = NULL;
  }

  m_iLevelHeight = 12 + m_iLevel * 3;

  m_fLevelOffset = 40.0f * m_iLevelHeight - 12 * 40.0f;

  m_pLevelData = new int[16 * m_iLevelHeight];

  for ( int i = 0; i < 16; ++i )
  {
    for ( int j = 0; j < m_iLevelHeight; ++j )
    {
      SetField( i, j, 0 );
    }
  }
  for ( int i = 0; i < 16; ++i )
  {
    SetField( i, m_iLevelHeight - 1, 1 );
  }

  // random Fires
  for ( int i = 0; i < 20 + m_iLevel * 10; ++i )
  {
    int   iX = 0;
    int   iY = 0;
    while ( true )
    {
      iX = rand() % 16;
      iY = rand() % ( m_iLevelHeight - 2 );

      if ( GetField( iX, iY ) == 0 )
      {
        break;
      }
    }
    // window on fire
    SetField( iX, iY, 2 );
    CFire*    pFire = new CFire();
    pFire->m_fX = iX * 40.0f;
    pFire->m_fY = iY * 40.0f;
    pFire->m_fAnimDelay += ( rand() % 100 ) * 0.005f;
    pFire->m_iTileX = iX;
    pFire->m_iTileY = iY;

    m_listUnits.push_back( pFire );
  }

  // random victims
  m_iVictimsToSave = 0;
  for ( int i = 0; i < 5 + m_iLevel * 5; ++i )
  {
    int   iX = 0;
    int   iY = 0;
    while ( true )
    {
      iX = rand() % 16;
      iY = rand() % ( m_iLevelHeight - 1 );

      if ( GetField( iX, iY ) == 0 )
      {
        break;
      }
    }
    // place a victim
    SetField( iX, iY, 3 );
    CVictim*    pVictim = new CVictim();
    pVictim->m_fX = iX * 40.0f;
    pVictim->m_fY = iY * 40.0f;
    pVictim->m_iTileX = iX;
    pVictim->m_iTileY = iY;

    m_listUnits.push_back( pVictim );
    ++m_iVictimsToSave;
  }

  m_pPlayer = new CPlayer();
  m_pPlayer->m_fX = 320.0f;
  m_pPlayer->m_fY = m_iLevelHeight * 40.0f - 80.0f;
  m_pPlayer->m_iTileX = 8;
  m_pPlayer->m_iTileY = m_iLevelHeight - 2;
  m_listUnits.push_back( m_pPlayer );

  m_fTimeLeft = 60.0f + m_iLevel * 30.0f;

}



void DirectXBase::SetField( int iX, int iY, int iValue )
{

  if ( ( iX >= 0 )
  &&   ( iX < 16 )
  &&   ( iY >= 0 )
  &&   ( iY < m_iLevelHeight ) )
  {
    m_pLevelData[iX + iY * 16] = iValue;
  }

}



int DirectXBase::GetField( int iX, int iY )
{

  if ( ( iX >= 0 )
  &&   ( iX < 16 )
  &&   ( iY >= 0 )
  &&   ( iY < m_iLevelHeight ) )
  {
    return m_pLevelData[iX + iY * 16];
  }
  return 0;

}



void DirectXBase::ClearUnits()
{

  tListUnits::iterator    it( m_listUnits.begin() );
  while ( it != m_listUnits.end() )
  {
    CUnit*    pUnit = *it;

    delete pUnit;

    ++it;
  }
  m_listUnits.clear();

}



void DirectXBase::RemoveUnitAt( int iX, int iY )
{

  if ( ( GetField( iX, iY ) != 2 )
  &&   ( GetField( iX, iY ) != 3 ) )
  {
    return;
  }

  SetField( iX, iY, 0 );

  tListUnits::iterator    it( m_listUnits.begin() );
  while ( it != m_listUnits.end() )
  {
    CUnit*    pUnit = *it;

    if ( ( pUnit->m_iTileX == iX )
    &&   ( pUnit->m_iTileY == iY )
    &&   ( !pUnit->m_bPlayerUnit ) )
    {
      pUnit->m_bRemoveMe = true;
    }
    ++it;
  }

}



void DirectXBase::DisplayNumber( int iX, int iY, int iValue, int iDigits, DWORD dwColor )
{

  for ( int i = 0; i < iDigits; ++i )
  {
    RenderQuad( iX + ( iDigits - i - 1 ) * 13, iY, 
                12, 16,
                1 + ( iValue % 10 ) * 13, 122,
                12, 16,
                dwColor );
    iValue /= 10;
  }

}