#include <windows.h>

#include <d3d9.h>

#include <string>
#include <map>
#include <list>

#include "Unit.h"



class CPlayer;

class DirectXBase
{

  public:

    typedef std::map<std::string,IDirect3DTexture9*>    tMapTextures;

    typedef std::list<CUnit*>                           tListUnits;

    tMapTextures                    m_mapTextures;

    tListUnits                      m_listUnits;

    int                             m_iLevel,
                                    m_iLevelHeight,
                                    m_iVictimsToSave,
                                    m_iLives;

    int*                            m_pLevelData;

    float                           m_fLevelOffset,
                                    m_fTimeLeft;

    bool                            m_bGameOver,
                                    m_bGetReady,
                                    m_bWellDone;

    CPlayer*                        m_pPlayer;

    bool                            m_bKeyPressed[256];
    bool                            m_bKeyReleased[256];


    void                                                DisplayFrame( IDirect3DDevice9* pDevice );
    void                                                UpdateFrame( const float fElapsedTime );

    void RenderQuad( int iX, int iY, int iWidth, int iHeight,
                                    int iTX, int iTY, int iTW, int iTH,
                                    DWORD dwColor = 0xffffffff );

	DirectXBase(HINSTANCE);
	~DirectXBase();

	// creation and deletion
	BOOL Init(BOOL windowed, int BPP, int Width, int Height);
	void Shutdown(void);

	INT Run();

	// Accessors
	LPDIRECT3DDEVICE9 GetDevice(){return m_pd3dDevice;}

	// generic window handler
	static LRESULT CALLBACK DispatchWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
	{
		if (message == WM_NCCREATE)
		{
			CREATESTRUCT* cs = (CREATESTRUCT*)lParam;
			SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG)(LONG_PTR)cs->lpCreateParams);

			return TRUE;
		}
		else
		{
			DirectXBase *app = (DirectXBase*)(LONG_PTR)GetWindowLongPtr(hWnd, GWLP_USERDATA);

			if (app!=NULL)
				return app->WndProc(hWnd, message, wParam, lParam);
			else
				return DefWindowProc(hWnd, message, wParam, lParam); 
		}
	}

	// class window handler
	LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

  void        LoadTexture( const std::string& strDesc, const char* szFileName, DWORD dwColorKey = 0 );

	BOOL bWindowed; // window mode
	int  iBpp;		// color depth
	int	 iWidth;	// window width
	int	 iHeight;   // window height

	HWND hWnd;		// device window
	HINSTANCE hInst;// application instance

	// Direct3D objects
	LPDIRECT3D9 m_pD3D;
	LPDIRECT3DDEVICE9 m_pd3dDevice;

	// intialization flag
	BOOL bInit;

	// windowing functions
	ATOM				RegisterClass(HINSTANCE);
	BOOL				InitInstance();

	// happy text
	char szWindowClass[32];
	char szTitle[32];

  void        PrepareLevel();
  void        ClearUnits();

  void        SetField( int iX, int iY, int iValue );
  int         GetField( int iX, int iY );

  void        RemoveUnitAt( int iX, int iY );

  void        DisplayNumber( int iX, int iY, int iValue, int iDigits, DWORD dwColor );

};




extern DirectXBase    theApp;