#include ".\victim.h"
#include ".\DXBase.h"



CVictim::CVictim()
{
}

CVictim::~CVictim(void)
{
}



void CVictim::Display()
{

  theApp.RenderQuad( (int)m_fX + 6, (int)( m_fY - theApp.m_fLevelOffset ) - 7, 39, 37,
                    50, 76,
                    39, 37 );

}



void CVictim::Update( const float fElapsedTime )
{

  CUnit::Update( fElapsedTime );

}