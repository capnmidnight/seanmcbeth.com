#include "DXBase.h"



int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{

  theApp.Init( TRUE, 16, 640, 480 );

  theApp.Run();
  
  theApp.Shutdown();

  return 0;

}
