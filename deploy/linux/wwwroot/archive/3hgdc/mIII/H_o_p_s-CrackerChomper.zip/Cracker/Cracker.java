import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.GraphicsConfiguration;
import java.util.Iterator;
import java.awt.Graphics2D;
import	javax.swing.JFrame;
import	javax.swing.JPanel;
import	java.awt.image.BufferStrategy;
import java.net.URL;
import javax.imageio.ImageIO;
import java.util.Random;
import java.awt.GraphicsConfiguration;
import	java.awt.RenderingHints;
import	java.awt.event.KeyListener;
import java.awt.Rectangle;
import	java.awt.event.KeyEvent;
import	java.awt.Graphics2D;
import java.util.ArrayList;

public class Cracker implements KeyListener {
	static Cracker 		Cracker;
	static BufferedImage 	Cracker_img;
	static BufferedImage	Mouth;
	static BufferStrategy 	bs;
	static JFrame 		frame;
	static Graphics2D	gi;
	static int		width  = 400;
	static int		height = 300;
	static ArrayList	texts;
	static ArrayList	images;
	static ArrayList	bullets;
	static ArrayList	badguys;
	static boolean[]  	kp; //KEYS PRESSED
	static long		next_add;
	static int		number_of_chomps;
	static long		add_wait;
	static int		add_wait_increase;
	
	static void init() {
		Cracker = new Cracker();
		Cracker.texts = new ArrayList();
		Cracker.images = new ArrayList();
		Cracker.bullets = new ArrayList();
		Cracker.badguys = new ArrayList();
		Cracker.images.add(0, new id(150,150));
		Cracker.images.add(new id(100,150));
		Cracker.images.add(new id(50,150));
		Cracker.input_creation();
		Cracker.create_window();
		Cracker.frame.addKeyListener(Cracker);
		Cracker.LoadCracker("cracker.gif");
		Cracker.LoadMouth("mouth.gif");
		Cracker.clear_window();
		Cracker.show_window();
		Cracker.add_text("Welcome to CrackerChomper!", 2, 35, 10);
		Cracker.next_add = System.currentTimeMillis()+2000;
		Cracker.add_wait = 2000;
		Cracker.add_wait_increase = 200;
		long time_end = System.currentTimeMillis()+60*1000;//One minutes
		
		while(System.currentTimeMillis() < time_end) {
			Cracker.clear_window();
			Cracker.update();
			Cracker.check_bangs();
			Cracker.draw_all_images();
			Cracker.draw_all_texts();
			Cracker.draw_text("Number of Chomps: "+Cracker.number_of_chomps,3, height - 20);
			Cracker.show_window();
		}
		System.out.println("END");
		Cracker.clear_window();
		Cracker.gi.setColor(java.awt.Color.WHITE);
		Cracker.draw_text("You have eaten "+Cracker.number_of_chomps+" crackers!", 3, 35);
		Cracker.show_window();
		
	}
	
	static void add() {
		Random r = new Random(System.currentTimeMillis());
		int x = r.nextInt(380);
		int y = r.nextInt(280);
			images.add(new id(x,y));
	}
	
	static void update() {
		if(System.currentTimeMillis() > next_add) {
			add();
			next_add = System.currentTimeMillis()+add_wait;
		}
			
		if(kp[KeyEvent.VK_UP]) {
			((id)images.get(0)).y--;
		}
		if(kp[KeyEvent.VK_DOWN]) {
			((id)images.get(0)).y++;
		}
		if(kp[KeyEvent.VK_LEFT]) {
			((id)images.get(0)).x--;
		}
		if(kp[KeyEvent.VK_RIGHT]) {
			((id)images.get(0)).x++;
		}
		if(kp[KeyEvent.VK_SPACE]) {
			add_text("Chomp!",((id)images.get(0)).x+16,((id)images.get(0)).y+40,1);
			kp[KeyEvent.VK_SPACE] = false;
		}
	}
	
	static boolean near(int x, int y, int x2, int y2) {
		Rectangle r1 = new Rectangle(x,y,64,64);
		Rectangle r2 = new Rectangle(x2,y2-10,20,10);
		gi.setColor(java.awt.Color.WHITE);
	//	gi.draw(r1);
	//	gi.draw(r2);
		return  r1.contains(r2);
	}
	
	static void check_bangs() {
		try {
			Iterator it = texts.iterator();
			while(it.hasNext()) {
				td temp = (td)it.next();
				
				Iterator it2 = images.iterator();
				while(it2.hasNext()) {
					id temp2 = (id)it2.next();
					if( near(temp2.x,temp2.y,temp.x,temp.y)) {
						if (temp2 != images.get(0)) {
							number_of_chomps++;
							images.remove(temp2);
							add_wait-=(add_wait/30);
						}
					}
				}
			}
		}  catch (Exception e) {}
		
		/*
		for(int i = 1; i<images.size(); i++) {
			for(int t = 0; t < texts.size(); t++) {
				try {
					if( near( ((id)images.get(i)).x, ((id)images.get(i)).y, ((td)texts.get(i)).x, ((td)texts.get(i)).y) ) {
						images.remove(i);
						t = texts.size();
					}
				} catch (Exception e) {}
			}
		}
		*/
	}
	
	
	static void input_creation() {
		kp = new boolean[256];
		for (int i = 0; i<256; i++) {
			kp[i] = false;
		}
	}
	
	static void create_window() {
		frame = new JFrame("Cracker Chomper");
		frame.setBounds(0, 0, width, height);
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent winEvt) {
				System.exit(0);
			}
		});
		frame.setIgnoreRepaint(true);
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation((screenSize.width/2 - width/2),(screenSize.height/2 - height/2));
		frame.setResizable(false);
		frame.setVisible(true);
		frame.createBufferStrategy(2);
		bs = frame.getBufferStrategy();
		gi = (Graphics2D)bs.getDrawGraphics();	
	}
	
	static void clear_window() {
		gi.setColor(java.awt.Color.BLACK);
		gi.fillRect(0, 0, width, height);
	}
	
	static void show_window() {
		bs.show();
	}
	
	static void add_text(String message, int x, int y, int time_in_seconds) {
		texts.add(new td(message, x, y, System.currentTimeMillis()+1000*time_in_seconds));
	}
	
	static void draw_text(String message, int x, int y) {
		gi.setColor(java.awt.Color.white);
		gi.drawString(message, x, y);
	}
	
	static void draw_cracker(int x, int y) {
		gi.drawImage(Cracker_img,x,y,null);
	}
	
	static void draw_mouth(int x, int y) {
		gi.drawImage(Mouth,x,y,null);
	}
	
	static void draw_all_texts() {
		try {
		Iterator it = texts.iterator();
		while(it.hasNext()) {
			td temp = (td)it.next();
			if( temp.time_to_stop_displaying < System.currentTimeMillis() ) {
				texts.remove(temp);
			} else {
				draw_text(temp.message, temp.x, temp.y);
			}
		}
		}  catch (Exception e) {}
	}
	
	static void draw_all_images() {
		for(int i = 1; i < images.size(); i++) {
			draw_cracker( ((id)images.get(i)).x, ((id)images.get(i)).y);
		}
		draw_mouth(((id)images.get(0)).x, ((id)images.get(0)).y);
	}
	
	public void LoadCracker(String FILENAME) {//NEW VERSION OF LOAD IMAGE
		URL url=null;
		BufferedImage initial = null;
		try { 
			url = getClass().getClassLoader().getResource(FILENAME); 
			initial = ImageIO.read(url);
			
			GraphicsConfiguration gC = frame.getGraphicsConfiguration(); //GET THE GRAPHICS CONFIGURATION FROM THE MIAIN FRAME
			BufferedImage result = gC.createCompatibleImage(initial.getWidth(),initial.getHeight(), initial.getColorModel().getTransparency());
			Graphics2D g = result.createGraphics();
			g.drawImage(initial,0,0,null);
			g.dispose();
			 
			Cracker_img = result;
			result = null;
			
		} catch (Exception e) {
			System.out.println(""+e);
			System.out.println("Couldn't load");
		}
	}
	
	public void LoadMouth(String FILENAME) {//NEW VERSION OF LOAD IMAGE
		URL url=null;
		BufferedImage initial = null;
		try { 
			url = getClass().getClassLoader().getResource(FILENAME); 
			initial = ImageIO.read(url);
			
			GraphicsConfiguration gC = frame.getGraphicsConfiguration(); //GET THE GRAPHICS CONFIGURATION FROM THE MIAIN FRAME
			BufferedImage result = gC.createCompatibleImage(initial.getWidth(),initial.getHeight(), initial.getColorModel().getTransparency());
			Graphics2D g = result.createGraphics();
			g.drawImage(initial,0,0,null);
			g.dispose();
			 
			Mouth = result;
			result = null;
			
		} catch (Exception e) {
			System.out.println(""+e);
			System.out.println("Couldn't load");
		}
	}
	
	public void keyPressed(KeyEvent e)  {kp[e.getKeyCode()] = true;System.out.print(e.getKeyChar());} //{im.kp[e.getKeyCode()] = true;System.out.println(e.getKeyCode()+"\n");
	public void keyReleased(KeyEvent e) {kp[e.getKeyCode()] = false;}
	public void keyTyped(KeyEvent e)    {}
	
	
	public static void main(String[] args) {
		init();
	}
}

class td {
	String message;
	int x;
	int y;
	long time_to_stop_displaying;
	public td(String m, int X, int Y, long t) {
		message = m;
		x = X;
		y = Y;
		time_to_stop_displaying = t;
	}
}

class id {//Image display, also a general entity
	int x;
	int y;
	public id(int X, int Y) {
		x=X;
		y=Y;
	}
}
