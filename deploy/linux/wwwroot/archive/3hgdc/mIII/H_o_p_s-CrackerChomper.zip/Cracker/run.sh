!# /bin/bash
java Cracker
