Cracka Attack

Created for a 3 hour gamedev contest themed: "cracker"

Controls:

	movement- A,S,D,W
	attack - left click
