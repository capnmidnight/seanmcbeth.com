import javax.swing.JFrame;
import java.awt.image.BufferStrategy;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Dimension;
import java.util.Random;
import java.awt.Toolkit;
import	java.awt.event.KeyListener;
import	java.awt.event.KeyEvent;

public class CARTS_Main {
	static CARTS_Main	c;
	static MidiDriver	m;
	static JFrame		frame;
	static BufferStrategy	buffer;
	static Graphics2D	graphics;
	static Keyboard		keyboard;
	
	static String	TITLE = "Color Arts Resources for Teachers and Students - Color Recognition";
	static int	WIDTH = 800;
	static int	HEIGHT = 600;
	
	static boolean[] lights = {false, false, false, false};
	
	static int[] theSequence;
	static int   theLength;
	
	public static void main(String[] args) {
		c = new CARTS_Main();
		c.clearScreen();
		c.renderScreen();
		c.showScreen();
		theSequence = generateSequence(25);
		for(theLength = 1; theLength < 20; theLength++) {
			c.sleep(2000);
			c.playSequence(subSequence(theSequence, theLength));
			c.getPlayerSequence();
		}
		
	}
	
	public CARTS_Main() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame = new JFrame(TITLE);
		frame.setIgnoreRepaint(true);
		frame.setResizable(false);
		frame.setFocusable(true);
		frame.setBounds(0, 0, WIDTH, HEIGHT);
		frame.setUndecorated(true);
		frame.setLocation((screenSize.width/2 - WIDTH/2),(screenSize.height/2 - HEIGHT/2));
		frame.setVisible(true);
		frame.createBufferStrategy(2);
		buffer = frame.getBufferStrategy();
		keyboard = new Keyboard(this);
	}
	
	public void clearScreen() {
		graphics = (Graphics2D) buffer.getDrawGraphics();
		graphics.setColor(Color.DARK_GRAY);
		graphics.fillRect(0, 0, WIDTH, HEIGHT);
	}
	
	public void renderScreen() {
		graphics.setColor(Color.BLACK);
		graphics.fillOval(100,0,600,600);
		if(lights[0]) {//TOP RED
			graphics.setColor(Color.RED);
			graphics.fillOval(300,50,200,200);
		} else {
			graphics.setColor(new Color(100, 0, 0));
			graphics.fillOval(300,50,200,200);
		}
		if(lights[1]) {//RIGHT BLUE
			graphics.setColor(Color.BLUE);
			graphics.fillOval(450,200,200,200);
		} else {
			graphics.setColor(new Color(0, 0, 100));
			graphics.fillOval(450,200,200,200);
		}
		if(lights[2]) {//BOTTOM GREEN
			graphics.setColor(Color.GREEN);
			graphics.fillOval(300,350,200,200);
		} else {
			graphics.setColor(new Color(0, 100, 0));
			graphics.fillOval(300,350,200,200);
		}
		if(lights[3]) {//LEFT YELLOW
			graphics.setColor(Color.YELLOW);
			graphics.fillOval(150,200,200,200);
		}  else {
			graphics.setColor(new Color(100, 100, 0));
			graphics.fillOval(150,200,200,200);
		}
	}
	
	public void showScreen() {
		buffer.show();
	}

	public void playSequence(int[] sequence) {
		for(int i = 0; i < sequence.length; i++) {
			lights[0] = false;
			lights[1] = false;
			lights[2] = false;
			lights[3] = false;
			clearScreen();
			renderScreen();
			showScreen();
			lights[0] = (sequence[i]==0);
			lights[1] = (sequence[i]==1);
			lights[2] = (sequence[i]==2);
			lights[3] = (sequence[i]==3);
			clearScreen();
			renderScreen();
			showScreen();
			sleep(350);
			lights[0] = false;
			lights[1] = false;
			lights[2] = false;
			lights[3] = false;
			clearScreen();
			renderScreen();
			showScreen();
			sleep(200);
		}
	}
	
	public void sleep(long ms) {
		try {
			Thread.sleep(ms);
		} catch (Exception e) {
		}
	}
	
	public static int[] generateSequence(int length) {
		int[] sequence = new int[length];
		Random r = new Random(System.currentTimeMillis());
		for(int i = 0; i < length; i++) {
			sequence[i] = r.nextInt(4);
		}
		return sequence;
	}
	
	public static int[] subSequence(int[] seq, int length) {
		int[] sequence = new int[length];
		for(int i = 0; i < length; i++) {
			sequence[i] = seq[i];
		}
		return sequence;
	}
	
	public void getPlayerSequence() {
		keyboard.length = 0;
		while(keyboard.length < theLength) {
			sleep(20);
		}
		if(!checkPlayerSequence(keyboard.keys, keyboard.length)) lose();
	}
	
	public boolean checkPlayerSequence(int[] ps, int length) {
		System.out.println("");
		System.out.print("Keyboard: ");
		for(int i = 0; i < length; i++) {
			System.out.print(ps[i]+", ");
		}
		System.out.println("");
		System.out.print("Actual: ");
		for(int i = 0; i < length; i++) {
			System.out.print(theSequence[i]+", ");
		}
		sleep(300);
			lights[0] = false;
			lights[1] = false;
			lights[2] = false;
			lights[3] = false;
			clearScreen();
			renderScreen();
			showScreen();
			sleep(300);
		return java.util.Arrays.equals(subSequence(ps, length), subSequence(theSequence, length));
			
	}
	
	public void lose() {
		System.out.println("LOSE");
		clearScreen();
		graphics.setColor(Color.WHITE);
		graphics.drawString("You Lose", 50, 50);
		showScreen();
		sleep(2000);
		frame.dispose();
		String[] args = {};
		main(args);
	}
	
}

class Keyboard implements KeyListener {
	int[] keys = new int[256];
	int   length = 0;
	CARTS_Main c;
	
	
	public Keyboard(CARTS_Main c) {
		c.frame.addKeyListener(this);
		this.c = c;
	}
	public void keyPressed(KeyEvent e)  {
		c.lights[0] = false;
		c.lights[1] = false;
		c.lights[2] = false;
		c.lights[3] = false;
		int temp = -1;
		if(e.getKeyCode()==KeyEvent.VK_UP) temp = 0;
		if(e.getKeyCode()==KeyEvent.VK_RIGHT) temp = 1;
		if(e.getKeyCode()==KeyEvent.VK_DOWN) temp = 2;
		if(e.getKeyCode()==KeyEvent.VK_LEFT) temp = 3;
		c.lights[temp] = true;
		c.clearScreen();
		c.renderScreen();
		c.showScreen();
		keys[length] = temp;
		length++;
	}
	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e)    {}
}
