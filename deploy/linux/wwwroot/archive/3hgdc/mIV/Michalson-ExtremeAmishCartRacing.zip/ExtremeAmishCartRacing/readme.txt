Extreme Amish Cart Racing by Michalson

I took way too long to get the sprites done for this (~2:30). Lots of frustration getting ImageReady to output the transparency correctly without messing up the sprite.

The game is obviously incomplete and not really playable as a game.

Your objective would have been to race to the finish line in your cart, avoiding extreme hazards like spikes, electric fences, etc. Your horse has a certain amount of stamina, represented by the portrait on the lower left. Pressing X will use some stamina to make the horse pull the cart faster. Pressing Y will use up all the horses stamina to jump - the height of the jump depends on how much stamina the horse has.

Requirements:

DirectX 9c
.NET 2.0 Framework
June Managed DirectX Update: http://nexe.gamedev.net/files/June%20MDX%20installer.zip