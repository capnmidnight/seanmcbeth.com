<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FastPixelForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.OptionsMenu = New System.Windows.Forms.MenuStrip
        Me.StretchModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CentredToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ZoomedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StretchedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EffectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BeardedBlokeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RandomPixelsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DisplayPictureBox = New System.Windows.Forms.PictureBox
        Me.TiledToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OptionsMenu.SuspendLayout()
        CType(Me.DisplayPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OptionsMenu
        '
        Me.OptionsMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StretchModeToolStripMenuItem, Me.EffectToolStripMenuItem})
        Me.OptionsMenu.Location = New System.Drawing.Point(0, 0)
        Me.OptionsMenu.Name = "OptionsMenu"
        Me.OptionsMenu.Size = New System.Drawing.Size(292, 24)
        Me.OptionsMenu.TabIndex = 0
        Me.OptionsMenu.Text = "MenuStrip1"
        '
        'StretchModeToolStripMenuItem
        '
        Me.StretchModeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CentredToolStripMenuItem, Me.ZoomedToolStripMenuItem, Me.StretchedToolStripMenuItem, Me.TiledToolStripMenuItem})
        Me.StretchModeToolStripMenuItem.Name = "StretchModeToolStripMenuItem"
        Me.StretchModeToolStripMenuItem.Size = New System.Drawing.Size(83, 20)
        Me.StretchModeToolStripMenuItem.Text = "Stretch Mode"
        '
        'CentredToolStripMenuItem
        '
        Me.CentredToolStripMenuItem.Name = "CentredToolStripMenuItem"
        Me.CentredToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CentredToolStripMenuItem.Text = "Centred"
        '
        'ZoomedToolStripMenuItem
        '
        Me.ZoomedToolStripMenuItem.Name = "ZoomedToolStripMenuItem"
        Me.ZoomedToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ZoomedToolStripMenuItem.Text = "Zoomed"
        '
        'StretchedToolStripMenuItem
        '
        Me.StretchedToolStripMenuItem.Name = "StretchedToolStripMenuItem"
        Me.StretchedToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.StretchedToolStripMenuItem.Text = "Stretched"
        '
        'EffectToolStripMenuItem
        '
        Me.EffectToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BeardedBlokeToolStripMenuItem, Me.RandomPixelsToolStripMenuItem})
        Me.EffectToolStripMenuItem.Name = "EffectToolStripMenuItem"
        Me.EffectToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.EffectToolStripMenuItem.Text = "Effect"
        '
        'BeardedBlokeToolStripMenuItem
        '
        Me.BeardedBlokeToolStripMenuItem.Name = "BeardedBlokeToolStripMenuItem"
        Me.BeardedBlokeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BeardedBlokeToolStripMenuItem.Text = "Bearded Bloke"
        '
        'RandomPixelsToolStripMenuItem
        '
        Me.RandomPixelsToolStripMenuItem.Name = "RandomPixelsToolStripMenuItem"
        Me.RandomPixelsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.RandomPixelsToolStripMenuItem.Text = "Random Pixels"
        '
        'DisplayPictureBox
        '
        Me.DisplayPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.DisplayPictureBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DisplayPictureBox.Location = New System.Drawing.Point(0, 24)
        Me.DisplayPictureBox.Name = "DisplayPictureBox"
        Me.DisplayPictureBox.Size = New System.Drawing.Size(292, 272)
        Me.DisplayPictureBox.TabIndex = 1
        Me.DisplayPictureBox.TabStop = False
        '
        'TiledToolStripMenuItem
        '
        Me.TiledToolStripMenuItem.Name = "TiledToolStripMenuItem"
        Me.TiledToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.TiledToolStripMenuItem.Text = "Tiled"
        '
        'FastPixelForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(292, 296)
        Me.Controls.Add(Me.DisplayPictureBox)
        Me.Controls.Add(Me.OptionsMenu)
        Me.DoubleBuffered = True
        Me.MainMenuStrip = Me.OptionsMenu
        Me.Name = "FastPixelForm"
        Me.Text = "Fast Pixel Writes"
        Me.OptionsMenu.ResumeLayout(False)
        Me.OptionsMenu.PerformLayout()
        CType(Me.DisplayPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OptionsMenu As System.Windows.Forms.MenuStrip
    Friend WithEvents StretchModeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CentredToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ZoomedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StretchedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EffectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BeardedBlokeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RandomPixelsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisplayPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents TiledToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
