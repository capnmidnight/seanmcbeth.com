Public Class FastPixelForm

    ' These are used for the output image...

    Dim BackBuffer As Bitmap    ' This is the backbuffer we'll write to
    Dim PixelArray() As Integer ' This is where the pixel data is stored before being written to the backbuffer


    ' Application flags
    Dim CloseMe As Boolean = False      ' Set to True when you want the program to be closed
    Dim RandomPixels As Boolean = False ' If True, show random pixels. If False, show the beard

    ' Bits and bobs for the effects
    Dim RandomPixelSource As New Random() ' Source of random pixel data

    Dim Beard() As Integer       ' The nice bearded gentleman, expanded to an array
    Dim SinTable(255) As Integer ' Sine table for fast trig operations for the ripple effect



    Private Sub FastPixelForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' First up we'll set things up for drawing to the form

        ' Create a new array of ints for the pixel data
        ReDim Me.PixelArray(256 * 256)

        ' Create the bitmap we'll use for the background
        Me.BackBuffer = New Bitmap(256, 256, PixelFormat.Format32bppRgb)

        ' Set the background image of the picturebox to the above backbuffer bitmap
        Me.DisplayPictureBox.BackgroundImage = Me.BackBuffer

        ' Make the form show itself
        Me.Show()

        ' Now we'll grab that pleasant bearded bloke from the project's resources

        ' Set up the array to hold the pixel data
        ReDim Me.Beard(256 * 256)

        ' Get the image from the project's resources
        Dim BeardOriginal As Bitmap = My.Resources.Beard

        ' Lock all of the bitmap for reading
        Dim Bd As BitmapData = BeardOriginal.LockBits(New Rectangle(0, 0, 256, 256), ImageLockMode.ReadOnly, PixelFormat.Format32bppRgb)

        ' Copy the pixel data to the array
        Marshal.Copy(Bd.Scan0, Me.Beard, 0, 256 * 256)

        ' Unlock the image
        BeardOriginal.UnlockBits(Bd)

        ' Dispose of it (no more need of it, Bitmaps are big objects)
        BeardOriginal.Dispose()

        ' Last of all, set up the Sin table for the ripple effect
        For i As Integer = 0 To 255
            SinTable(i) = Math.Round(16D * Math.Sin((i * Math.PI * 2D) / 256D), 0)
        Next

        ' Now just loop aimlessly, calling Render()
        Do Until Me.CloseMe
            Render()
            Application.DoEvents()
        Loop

        ' Clean up the bitmap used
        Me.BackBuffer.Dispose()

        ' Dispose of myself
        Me.Dispose()

    End Sub

    Private Sub FastPixelForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        ' About to close... set the 'closing' flag
        CloseMe = True
        ' We don't want the form to get rid of itself until we've cleaned up, so stop it from doing so
        e.Cancel = True
    End Sub


    Private Sub Render()

        ' Either render random pixels or do a simple warp effect to the pixel array:

        If RandomPixels Then

            ' Fills the array with random values between &H000000 (black) and &HFFFFFF (white)
            For i As Integer = 0 To 256 * 256 - 1
                Me.PixelArray(i) = RandomPixelSource.Next(&HFFFFFF)
            Next

        Else

            ' When plotting pixels, it just offsets using a sine function + time to ripple the image
            ' Note the use of And &HFF - this clamps a value between 0->255, which is perfect for
            ' our 256 item sine table and our 256x256 source image (see why powers of two are important?)
            Dim AnimationProgress As Integer = (DateTime.Now.Ticks / 40000) Mod 256
            For y As Integer = 0 To 255
                For x As Integer = 0 To 255
                    Me.PixelArray(x + y * 256) = Me.Beard(((x + SinTable(y + AnimationProgress And &HFF)) And &HFF) + ((y + SinTable(x + AnimationProgress And &HFF)) And &HFF) * 256)
                Next
            Next

        End If


        ' Now, we need to write this to the BackBuffer bitmap

        ' Lock all of it (that's the rectangle bit specifying what to lock).
        Dim Bd As BitmapData = Me.BackBuffer.LockBits(New Rectangle(0, 0, 256, 256), ImageLockMode.WriteOnly, PixelFormat.Format32bppRgb)

        ' Copy over the array to the bitmap in one go
        ' (NB: Marshal is in the System.Runtime.InteropServices namespace)
        Marshal.Copy(Me.PixelArray, 0, Bd.Scan0, 256 * 256)

        ' Unlock the bitmap
        Me.BackBuffer.UnlockBits(Bd)

        ' Cause the picture box to redraw itself
        Me.DisplayPictureBox.Invalidate()

    End Sub


#Region "Stretch menu options"

    Private Sub StretchModeToolStripMenuItem_DropDownOpening(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StretchModeToolStripMenuItem.DropDownOpening
        Me.CentredToolStripMenuItem.Checked = Me.DisplayPictureBox.BackgroundImageLayout = ImageLayout.Center
        Me.ZoomedToolStripMenuItem.Checked = Me.DisplayPictureBox.BackgroundImageLayout = ImageLayout.Zoom
        Me.StretchedToolStripMenuItem.Checked = Me.DisplayPictureBox.BackgroundImageLayout = ImageLayout.Stretch
        Me.TiledToolStripMenuItem.Checked = Me.DisplayPictureBox.BackgroundImageLayout = ImageLayout.Tile
    End Sub

    Private Sub CentredToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CentredToolStripMenuItem.Click
        Me.DisplayPictureBox.BackgroundImageLayout = ImageLayout.Center
    End Sub

    Private Sub ZoomedToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomedToolStripMenuItem.Click
        Me.DisplayPictureBox.BackgroundImageLayout = ImageLayout.Zoom
    End Sub

    Private Sub StretchedToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StretchedToolStripMenuItem.Click
        Me.DisplayPictureBox.BackgroundImageLayout = ImageLayout.Stretch
    End Sub

    Private Sub TiledToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TiledToolStripMenuItem.Click
        Me.DisplayPictureBox.BackgroundImageLayout = ImageLayout.Tile
    End Sub

#End Region

#Region "Effect menu options"

    Private Sub EffectToolStripMenuItem_DropDownOpening(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EffectToolStripMenuItem.DropDownOpening
        Me.BeardedBlokeToolStripMenuItem.Checked = Not RandomPixels
        Me.RandomPixelsToolStripMenuItem.Checked = RandomPixels
    End Sub

    Private Sub BeardedBlokeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BeardedBlokeToolStripMenuItem.Click
        RandomPixels = False
    End Sub

    Private Sub RandomPixelsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RandomPixelsToolStripMenuItem.Click
        RandomPixels = True
    End Sub

#End Region


End Class
