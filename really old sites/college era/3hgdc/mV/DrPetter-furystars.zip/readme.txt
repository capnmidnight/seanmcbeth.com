arrow keys, up is jump

there are two stars that move up and down, the other one is to the right

avoid falling into the water

/drpetter