Entry for 3H-GDC at gamedev.net

Author - Chris Crowe (extralongpants)

The executable is in Game/bin.  Change the ThePits.ex file's extension to 'exe' before
running it.