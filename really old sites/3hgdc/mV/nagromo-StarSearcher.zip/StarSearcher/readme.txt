Hi, all.

Please don't run AnnoyingBeeper.exe. It's annoying. It's not malicious or 
anything; it just beeps until you press escape or close the window. It was 
the result of my trying to get some music ready before the contest started, 
but as you can tell, I didn't get music ready in time.

For best results (both visually and speed-wise) please use fullscreen mode 
by pressing Alt+Enter.

Controls:
Arrows: move
Escape: exit

Good luck!

Feel free to edit the level.txt file; especially the number of random spawns.